"""
Keyframed Susanoo actions, one set per stage: the three combo swings, the special (right-click) and the blocking pose.
Each action is a list of (tick, {bone: [x, y, z] degrees}); a bone missing from a key is at rest there. Rotations are
applied Z, then Y, then X (like Minecraft's model parts) about the bone's pivot. In model space the Susanoo faces +Z,
its right side is -X, so for a limb hanging down a negative X angle swings it forward and up, a positive Y angle turns
it toward the model's left. Idle breathing, walking and wing flaps are worked out in the mod (SusanooPose.java).

The server's hit ticks (when damage lands) are in Susanoo.java and match the strike keys here:
swings at tick 7 (the third at 9), specials at tick 12 (stage 3: 9, stage 5: 14).
"""

# claws / fists without a weapon (stage 2)
S2 = {
    "swing1": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_r": [-60, -55, 0], "fore_r": [-15, 0, 0], "body": [0, -12, 0]}),
                                   (7, {"arm_r": [-78, 45, 0], "fore_r": [-5, 0, 0], "body": [0, 12, 0]}),
                                   (14, {})]},
    "swing2": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_l": [-60, 55, 0], "fore_l": [-15, 0, 0], "body": [0, 12, 0]}),
                                   (7, {"arm_l": [-78, -45, 0], "fore_l": [-5, 0, 0], "body": [0, -12, 0]}),
                                   (14, {})]},
    "swing3": {"len": 16, "keys": [(0, {}),
                                   (5, {"arm_r": [-155, 10, 0], "arm_l": [-155, -10, 0], "body": [-8, 0, 0], "jaw": [18, 0, 0]}),
                                   (9, {"arm_r": [-55, 10, 0], "arm_l": [-55, -10, 0], "body": [18, 0, 0], "jaw": [5, 0, 0]}),
                                   (16, {})]},
    "special": {"len": 22, "keys": [(0, {}),
                                    (8, {"arm_r": [-165, 15, 0], "arm_l": [-165, -15, 0], "body": [-12, 0, 0], "head": [-10, 0, 0], "jaw": [25, 0, 0]}),
                                    (12, {"arm_r": [-40, 10, 0], "arm_l": [-40, -10, 0], "body": [25, 0, 0], "jaw": [10, 0, 0]}),
                                    (22, {})]},
    "block": {"arm_r": [-65, 40, 0], "fore_r": [-35, 0, 0], "arm_l": [-65, -40, 0], "fore_l": [-35, 0, 0], "body": [6, 0, 0]},
}

# a sword in the right hand (stages 3 and 4); the sword's own X turn levels the blade for the side cuts
SWORD = {
    "swing1": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_r": [-20, -70, 0], "sword": [25, 0, 0], "torso": [0, -25, 0]}),
                                   (7, {"arm_r": [-25, 55, 0], "sword": [25, 0, 0], "torso": [0, 25, 0]}),
                                   (14, {})]},
    "swing2": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_r": [-25, 55, 0], "sword": [25, 0, 0], "torso": [0, 25, 0]}),
                                   (7, {"arm_r": [-20, -70, 0], "sword": [25, 0, 0], "torso": [0, -25, 0]}),
                                   (14, {})]},
    "swing3": {"len": 16, "keys": [(0, {}),
                                   (5, {"arm_r": [-115, 10, 0], "torso": [-10, 0, 0]}),
                                   (9, {"arm_r": [10, 10, 0], "sword": [30, 0, 0], "torso": [15, 0, 0]}),
                                   (16, {})]},
}

S3 = dict(SWORD)
S3["special"] = {"len": 18, "keys": [(0, {}),                      # the magatama, thrown with the left hand
                                     (6, {"arm_l": [-30, -40, 0], "torso": [0, 20, 0]}),
                                     (9, {"arm_l": [-95, 10, 0], "fore_l": [-10, 0, 0], "torso": [0, -15, 0]}),
                                     (18, {})]}
S3["block"] = {"arm_r": [-45, 60, 0], "arm_l": [-40, -30, 0], "fore_l": [-20, 0, 0]}

S4 = dict(SWORD)
S4["special"] = {"len": 22, "keys": [(0, {}),                      # one huge overhead cut sends the slash wave out
                                     (8, {"arm_r": [-125, 15, 0], "torso": [-12, -10, 0]}),
                                     (12, {"arm_r": [10, 20, 0], "sword": [30, 0, 0], "torso": [18, 10, 0]}),
                                     (22, {})]}
S4["block"] = {"arm_l": [-40, -20, 0], "arm_r": [-10, -10, 0]}    # the shield up in front

# the greatsword, held in both hands (it hangs from the right hand, so its own angle adds to the arms'; both arms turn
# alike so the hands stay together)
S5 = {
    "swing1": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_r": [-40, -35, 0], "arm_l": [-40, -35, 0], "greatsword": [-50, -60, 0], "body": [0, -25, 0]}),
                                   (7, {"arm_r": [-40, 35, 0], "arm_l": [-40, 35, 0], "greatsword": [-50, 60, 0], "body": [0, 25, 0]}),
                                   (14, {})]},
    "swing2": {"len": 14, "keys": [(0, {}),
                                   (4, {"arm_r": [-40, 35, 0], "arm_l": [-40, 35, 0], "greatsword": [-50, 60, 0], "body": [0, 25, 0]}),
                                   (7, {"arm_r": [-40, -35, 0], "arm_l": [-40, -35, 0], "greatsword": [-50, -60, 0], "body": [0, -25, 0]}),
                                   (14, {})]},
    "swing3": {"len": 16, "keys": [(0, {}),
                                   (5, {"arm_r": [-70, 0, 0], "arm_l": [-70, 0, 0], "greatsword": [-130, 0, 0], "body": [-4, 0, 0]}),
                                   (9, {"arm_r": [-30, 0, 0], "arm_l": [-30, 0, 0], "greatsword": [-45, 0, 0], "body": [5, 0, 0]}),
                                   (16, {})]},
    "special": {"len": 26, "keys": [(0, {}),
                                    (10, {"arm_r": [-80, -10, 0], "arm_l": [-80, -10, 0], "greatsword": [-130, 0, 0],
                                          "body": [-4, -15, 0], "wing_r": [0, 0, -20], "wing_l": [0, 0, 20]}),
                                    (14, {"arm_r": [-25, 10, 0], "arm_l": [-25, 10, 0], "greatsword": [-45, 0, 0],
                                          "body": [6, 15, 0], "wing_r": [0, 0, 15], "wing_l": [0, 0, -15]}),
                                    (26, {})]},
    "block": {"wing_r": [0, 70, -10], "wing_l": [0, -70, 10]},
}

S1 = {"block": {"body": [8, 0, 0]}}

ANIMS = {1: S1, 2: S2, 3: S3, 4: S4, 5: S5}

# bones moved to another parent for animation (the stage 5 greatsword follows the right hand)
REPARENT = {5: {"greatsword": "hand_r"}}


def to_json():
    out = {}
    for stage, acts in ANIMS.items():
        o = {}
        for name, a in acts.items():
            if name == "block":
                o[name] = {b: [float(v) for v in r] for b, r in a.items()}
            else:
                o[name] = {"len": a["len"], "keys": [[t, {b: [float(v) for v in r] for b, r in pose.items()}] for t, pose in a["keys"]]}
        out[str(stage)] = o
    return out
