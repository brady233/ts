"""
Converts the provided models (tools/source_art/*.glb and tools/source_art/weapons/*.obj) into Forge OBJ
models + textures, and renders an inventory icon for each.

Each model is laid out like a Minecraft item sprite: handle at the bottom-left, tip toward the top-right,
flat side facing the camera, inside the 0..1 block space. That way vanilla-style held-item transforms
put the grip in the player's hand. Run: python3 tools/convert_models.py [preview_dir] [model ...]
Needs: pip install trimesh pygltflib pillow numpy
"""
import io
import math
import os
import sys
from types import SimpleNamespace

import numpy as np
import pygltflib
import trimesh
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art")
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")
OBJ_DIR = os.path.join(ASSETS, "models", "item", "obj")
TEX_DIR = os.path.join(ASSETS, "textures", "item", "model")
ICON_DIR = os.path.join(ASSETS, "textures", "item")

DIAG = np.array([1.0, 1.0, 0.0]) / math.sqrt(2)
CROSS = np.array([-1.0, 1.0, 0.0]) / math.sqrt(2)

# name: settings
#   parts      - geometry names to keep (None = all)
#   handle     - which end of the long axis is the handle: "+" or "-" (along the model's main axis)
#   length     - length along the diagonal, in blocks
#   grip       - (fraction of length from the handle end, target x=y coordinate) for the hand position;
#                None = center the model in the block (for things held in the middle, like scrolls)
#   roll       - extra rotation (degrees) around the long axis, to choose which side faces out
#   tex        - texture size to downscale to
#   pixel      - True for pixel-art textures (scaled with nearest-neighbour so they stay crisp)
#   mats       - OBJ only: material name -> texture file in source_art/weapons (None = faces with no material)
#   tex_file   - replace the model's own texture with this file from source_art (e.g. a model that is black
#                because it relies on metal reflections Minecraft doesn't have)
#   axes       - (long axis, cross axis) in the source model's coordinates, instead of finding them automatically
#   icon       - False if the item has a hand-drawn inventory icon (no rendered icon needed)
MODELS = {
    "kunai": {"src": "kunai.glb", "parts": None, "handle": "+", "length": 1.2, "grip": (0.13, 0.16), "roll": 0, "tex": 256},
    # Shuriken: lies flat facing the camera, one point toward each corner of the block. The model's own color is
    # nearly black (it relies on metal reflections), so it uses a gunmetal texture instead.
    "shuriken": {"src": "shuriken.glb", "parts": None, "handle": "+", "length": 0.8, "grip": None, "roll": 0, "tex": 128,
                 "axes": ((1, 0, 1), (-1, 0, 1)), "tex_file": "shuriken_metal.png"},
    "zabuza_blade": {"src": "zabuza_blade.glb", "parts": None, "handle": "-", "length": 3.3, "grip": (0.07, 0.14), "roll": 180, "tex": 512},
    # Samehada: recoloured by tools/recolor_samehada.py (blue shark-skin scales, off-white bandages, blue grip).
    "samehada": {"src": "samehada.glb", "parts": None, "handle": "-", "length": 3.3, "grip": (0.12, 0.14), "roll": 0, "tex": 256,
                 "pixel": True, "tex_file": "samehada_recolor.png"},
    "kusanagi": {"src": "weapons/kusanagi.obj", "mats": {"1.001": "kusanagi.png"},
                 "handle": "-", "length": 1.5, "grip": (0.12, 0.16), "roll": 0, "tex": 256},
    "katana": {"src": "weapons/katana.obj", "mats": {"1.001": "katana.png"},
               "handle": "-", "length": 1.5, "grip": (0.12, 0.16), "roll": 0, "tex": 256},
    "hidan_scythe": {"src": "weapons/hidan_scythe.obj", "mats": {"1": "hidan_scythe_pole.png", "2": "hidan_scythe_blades.png"},
                     "handle": "+", "length": 2.5, "grip": (0.1, 0.14), "roll": 0, "tex": 256, "pixel": True},
    "sword_of_fire": {"src": "weapons/sword_of_fire.obj",
                      "mats": {"Material.001": "sword_of_fire_blade.png", "Material.002": "sword_of_fire_guard.png",
                               "Material.003": "sword_of_fire_dragon.png", "Material.004": "sword_of_fire_handle.png",
                               None: "sword_of_fire_dark.png"},
                      "handle": "-", "length": 1.9, "grip": (0.08, 0.15), "roll": 0, "tex": 512},
    "shakujo": {"src": "weapons/shakujo.obj", "mats": {None: "shakujo.png"},
                "handle": "-", "length": 2.4, "grip": (0.3, 0.2), "roll": 0, "tex": 256},
    # Kiba (Nelesh_surve): one blade; the second one in the off hand is the same model (dual wield).
    "kiba": {"src": "kiba.glb", "parts": ["handle_handle1_0", "hilt_handle1_0", "blade_blade1_0"], "handle": "-", "length": 1.3,
             "grip": (0.12, 0.16), "roll": 0, "tex": 64, "axes": ((0, 1, 0), (1, 0, 0))},
    # Kabutowari (Xnropa): the axe is the item, the hammer is drawn in the off hand; the chain between them is left out.
    "kabutowari": {"src": "kabutowari.glb", "parts": ["Object_0", "Object_1", "Object_2", "Object_6", "Object_7", "Object_8",
                                                       "Object_9", "Object_10", "Object_11"],
                   "handle": "-", "length": 2.025, "grip": (0.22, 0.16), "roll": 0, "tex": 256, "axes": ((0, 1, 0), (1, 0, 1))},
    "kabutowari_hammer": {"src": "kabutowari.glb", "parts": ["Object_4", "Object_5", "Object_12", "Object_13", "Object_14",
                                                              "Object_15", "Object_16", "Object_17"],
                          "handle": "-", "length": 1.74, "grip": (0.25, 0.16), "roll": 0, "tex": 256, "axes": ((0, 1, 0), (1, 0, 0)),
                          "icon": False},
    # Gunbai (DontQuitIdol)
    "gunbai": {"src": "gunbai.glb", "parts": None, "handle": "-", "length": 2.7, "grip": (0.1, 0.16), "roll": 0, "tex": 128,
               "pixel": True, "axes": ((0, 1, 0), (1, 0, 0))},
    "scroll_jutsu": {"src": "scrolls.glb", "parts": ["Circle.002_Material.001_0"], "handle": "+", "length": 0.95, "grip": None,
                     "roll": 135, "tex": 256, "icon": False},
    "scroll_training": {"src": "scrolls.glb", "parts": ["Circle.003_Material.003_0"], "handle": "+", "length": 0.95, "grip": None,
                        "roll": 135, "tex": 256, "icon": False},
    "scroll_blank": {"src": "scrolls.glb", "parts": ["Circle.004_Material.002_0"], "handle": "+", "length": 0.95, "grip": None,
                     "roll": 135, "tex": 256, "icon": False},
}


def load_parts(path, parts):
    """Returns [(name, mesh_in_world_space, material_index)] and the glTF images by material."""
    gltf = pygltflib.GLTF2().load(path)
    blob = gltf.binary_blob()
    mat_images = {}
    for mi, m in enumerate(gltf.materials):
        pbr = m.pbrMetallicRoughness
        if pbr and pbr.baseColorTexture is not None:
            img = gltf.images[gltf.textures[pbr.baseColorTexture.index].source]
            bv = gltf.bufferViews[img.bufferView]
            mat_images[mi] = Image.open(io.BytesIO(blob[bv.byteOffset: bv.byteOffset + bv.byteLength])).convert("RGBA")
        else:
            color = [int(255 * c) for c in (pbr.baseColorFactor if pbr else [1, 1, 1, 1])]
            mat_images[mi] = Image.new("RGBA", (16, 16), tuple(color))
    mesh_material = {}
    for i, mesh in enumerate(gltf.meshes):
        mesh_material[mesh.name] = mesh.primitives[0].material or 0

    scene = trimesh.load(path, force="scene")
    out = []
    for node in scene.graph.nodes_geometry:
        transform, gname = scene.graph[node]
        if parts is not None and gname not in parts:
            continue
        mesh = scene.geometry[gname].copy()
        mesh.apply_transform(transform)
        mat = mesh_material.get(gname, mesh_material.get(gname.rsplit("_", 1)[0], 0))
        out.append((gname, mesh, mat))
    return out, mat_images


def load_obj_parts(path, mats):
    """Reads a Wavefront OBJ. Returns one part per material, shaped like load_parts() output."""
    V, VT, VN = [], [], []
    faces = {}  # material -> [((vi, ti, ni), x3)]
    mat = None
    for line in open(path, encoding="utf-8", errors="ignore"):
        t = line.split()
        if not t:
            continue
        if t[0] == "v":
            V.append([float(x) for x in t[1:4]])
        elif t[0] == "vt":
            VT.append([float(x) for x in t[1:3]])
        elif t[0] == "vn":
            VN.append([float(x) for x in t[1:4]])
        elif t[0] == "usemtl":
            mat = " ".join(t[1:])
        elif t[0] == "f":
            corners = []
            for c in t[1:]:
                p = c.split("/")
                idx = []
                for k, pool in enumerate((V, VT, VN)):
                    if k < len(p) and p[k]:
                        i = int(p[k])
                        idx.append(i - 1 if i > 0 else len(pool) + i)
                    else:
                        idx.append(-1)
                corners.append(tuple(idx))
            for k in range(1, len(corners) - 1):  # fan-triangulate quads/polygons
                faces.setdefault(mat, []).append((corners[0], corners[k], corners[k + 1]))
    V, VT, VN = np.array(V), np.array(VT) if VT else np.zeros((1, 2)), np.array(VN) if VN else np.zeros((1, 3))

    parts, images = [], {}
    for mat, tris in faces.items():
        if mat not in mats:
            raise KeyError(f"{path}: no texture given for material {mat!r}")
        images[mat] = Image.open(os.path.join(SRC, "weapons", mats[mat])).convert("RGBA")
        index, verts, uvs, normals, out = {}, [], [], [], []
        for tri in tris:
            face_n = np.cross(V[tri[1][0]] - V[tri[0][0]], V[tri[2][0]] - V[tri[0][0]])
            face_n = face_n / (np.linalg.norm(face_n) + 1e-12)
            f = []
            for vi, ti, ni in tri:
                key = (vi, ti, ni if ni >= 0 else tuple(np.round(face_n, 4)))
                if key not in index:
                    index[key] = len(verts)
                    verts.append(V[vi])
                    uvs.append(VT[ti] if ti >= 0 else (0.0, 0.0))
                    normals.append(VN[ni] if ni >= 0 else face_n)
                f.append(index[key])
            out.append(f)
        mesh = SimpleNamespace(vertices=np.array(verts), faces=np.array(out), vertex_normals=np.array(normals),
                               visual=SimpleNamespace(uv=np.array(uvs, dtype=float)))
        parts.append((str(mat or "plain"), mesh, mat))
    return parts, images


def layout(meshes, cfg):
    verts = np.vstack([m.vertices for _, m, _ in meshes])
    center = verts.mean(0)
    if cfg.get("axes"):
        a = np.array(cfg["axes"][0], dtype=float)
        a /= np.linalg.norm(a)
        b = np.array(cfg["axes"][1], dtype=float)
        b -= a * (b @ a)
        b /= np.linalg.norm(b)
    else:
        _, _, vt = np.linalg.svd(verts - center, full_matrices=False)
        a, b = vt[0], vt[1]
    proj = (verts - center) @ a
    # point a from handle to tip
    if (cfg["handle"] == "-" and a[np.argmax(np.abs(a))] < 0) or (cfg["handle"] == "+" and a[np.argmax(np.abs(a))] > 0):
        a = -a
    roll = math.radians(cfg["roll"])
    c = np.cross(a, b)
    b, c = b * math.cos(roll) + c * math.sin(roll), -b * math.sin(roll) + c * math.cos(roll)
    rot = np.outer(DIAG, a) + np.outer(CROSS, b) + np.outer(np.array([0, 0, 1.0]), c)

    proj = (verts - center) @ a
    lo, hi = proj.min(), proj.max()
    scale = cfg["length"] / (hi - lo)

    def place(v):
        local = (v - center) @ rot.T * scale  # rotated + scaled, centered at origin
        return local

    placed_all = place(verts)
    along = placed_all @ DIAG
    handle_end = along.min()
    if cfg["grip"] is None:
        mid = (along.min() + along.max()) / 2
        offset = np.array([0.5, 0.5, 0.5]) - DIAG * mid
    else:
        frac, target = cfg["grip"]
        grip_along = handle_end + frac * cfg["length"]
        offset = np.array([target, target, 0.5]) - DIAG * grip_along
    z_mid = (placed_all[:, 2].min() + placed_all[:, 2].max()) / 2
    offset[2] = 0.5 - z_mid
    return lambda v: place(v) + offset, rot


def write_obj(name, meshes, mat_images, cfg):
    os.makedirs(OBJ_DIR, exist_ok=True)
    os.makedirs(TEX_DIR, exist_ok=True)
    transform, rot = layout(meshes, cfg)
    lines = [f"# {name} - converted from provided art by tools/convert_models.py", f"mtllib {name}.mtl"]
    mtl = []
    textures = {}
    small_images = {}
    v_off = vt_off = vn_off = 1
    all_tris = []
    for idx, (gname, mesh, mat) in enumerate(meshes):
        key = f"tex{len(textures)}" if mat not in [m for m, _ in textures.values()] else None
        if key is not None:
            tex_name = f"{name}_{len(textures)}"
            img = mat_images[mat]
            size = min(cfg["tex"], img.width)
            small = img.resize((size, size), Image.NEAREST if cfg.get("pixel") else Image.LANCZOS)
            small.save(os.path.join(TEX_DIR, tex_name + ".png"))
            small_images[mat] = small
            textures[key] = (mat, tex_name)
            mtl += [f"newmtl {key}", "Kd 1.0 1.0 1.0", "d 1.0", f"map_Kd #{key}", ""]
        use = next(k for k, (m, _) in textures.items() if m == mat)
        v = transform(mesh.vertices)
        n = mesh.vertex_normals @ rot.T
        uv = np.asarray(mesh.visual.uv, dtype=float)  # trimesh gives bottom-up V; Minecraft/Forge expect top-down
        lines.append(f"o {gname.replace(' ', '_')}")
        lines.append(f"usemtl {use}")
        lines += [f"v {x:.5f} {y:.5f} {z:.5f}" for x, y, z in v]
        lines += [f"vn {x:.4f} {y:.4f} {z:.4f}" for x, y, z in n]
        if uv.min() < -1e-4 or uv.max() > 1 + 1e-4:
            # The model tiles its texture (UVs outside 0..1). Minecraft can't repeat a texture: out-of-range UVs
            # read the neighbouring textures in the atlas and look glitchy. Shift every triangle back into 0..1
            # (each one fits inside a single tile), giving each face corner its own UV.
            tri_uv = uv[mesh.faces]
            tri_uv = tri_uv - np.floor(tri_uv.min(1) + 1e-4)[:, None, :]
            tri_uv = np.clip(tri_uv, 0.0, 1.0)
            tri_top = np.stack([tri_uv[..., 0], 1.0 - tri_uv[..., 1]], -1)
            lines += [f"vt {u:.5f} {w:.5f}" for u, w in tri_top.reshape(-1, 2)]
            for i, f in enumerate(mesh.faces):
                a, b, c = (int(k) for k in f)
                t0 = vt_off + 3 * i
                lines.append(f"f {a + v_off}/{t0}/{a + vn_off} {b + v_off}/{t0 + 1}/{b + vn_off} {c + v_off}/{t0 + 2}/{c + vn_off}")
                all_tris.append((v[[a, b, c]], tri_top[i], n[[a, b, c]], mat))
            vt_off += 3 * len(mesh.faces)
        else:
            uv_top = np.column_stack([uv[:, 0], 1.0 - uv[:, 1]])
            lines += [f"vt {u:.5f} {w:.5f}" for u, w in uv_top]
            for f in mesh.faces:
                a, b, c = (int(i) for i in f)
                lines.append(f"f {a + v_off}/{a + vt_off}/{a + vn_off} {b + v_off}/{b + vt_off}/{b + vn_off} {c + v_off}/{c + vt_off}/{c + vn_off}")
                all_tris.append((v[[a, b, c]], uv_top[[a, b, c]], n[[a, b, c]], mat))
            vt_off += len(uv)
        v_off += len(v)
        vn_off += len(n)
    open(os.path.join(OBJ_DIR, name + ".obj"), "w").write("\n".join(lines) + "\n")
    open(os.path.join(OBJ_DIR, name + ".mtl"), "w").write("\n".join(mtl))
    tex_map = {k: f"shinobiarts:item/model/{t}" for k, (_, t) in textures.items()}
    bounds = np.vstack([t[0] for t in all_tris])
    return tex_map, all_tris, (bounds.min(0), bounds.max(0)), small_images


def outline_icon(icon):
    """Adds a 1-pixel dark outline, like vanilla item icons, so the icon reads well on the inventory slot."""
    a = np.asarray(icon, dtype=np.float32) / 255
    alpha = a[..., 3]
    grown = alpha.copy()
    for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        grown = np.maximum(grown, np.roll(np.roll(alpha, dy, 0), dx, 1))
    ring = np.clip(grown - alpha, 0, 1) * 0.85
    out = np.zeros_like(a)
    out[..., :3] = a[..., :3] * alpha[..., None] + 0.09 * ring[..., None]
    out[..., 3] = alpha + ring * (1 - alpha)
    out[..., :3] /= np.maximum(out[..., 3:4], 1e-6)
    return Image.fromarray((np.clip(out, 0, 1) * 255).round().astype(np.uint8), "RGBA")


def render(tris, mat_images, size, view_min=0.0, view_max=1.0, light=True):
    """Tiny software rasterizer: orthographic front view of the XY plane (used for previews and GUI icons)."""
    img = np.zeros((size, size, 4), dtype=np.float32)
    zbuf = np.full((size, size), -1e9, dtype=np.float32)
    texs = {m: np.asarray(im.convert("RGBA"), dtype=np.float32) / 255.0 for m, im in mat_images.items()}
    span = view_max - view_min
    light_dir = np.array([-0.4, 0.6, 0.7]); light_dir /= np.linalg.norm(light_dir)
    for verts, uv, normals, mat in tris:
        px = (verts[:, 0] - view_min) / span * size
        py = (1 - (verts[:, 1] - view_min) / span) * size
        x0, x1 = int(max(0, math.floor(px.min()))), int(min(size - 1, math.ceil(px.max())))
        y0, y1 = int(max(0, math.floor(py.min()))), int(min(size - 1, math.ceil(py.max())))
        if x1 < x0 or y1 < y0:
            continue
        xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        d = (py[1] - py[2]) * (px[0] - px[2]) + (px[2] - px[1]) * (py[0] - py[2])
        if abs(d) < 1e-9:
            continue
        w0 = ((py[1] - py[2]) * (xs - px[2]) + (px[2] - px[1]) * (ys - py[2])) / d
        w1 = ((py[2] - py[0]) * (xs - px[2]) + (px[0] - px[2]) * (ys - py[2])) / d
        w2 = 1 - w0 - w1
        inside = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
        if not inside.any():
            continue
        z = w0 * verts[0, 2] + w1 * verts[1, 2] + w2 * verts[2, 2]
        sub = zbuf[y0:y1 + 1, x0:x1 + 1]
        mask = inside & (z > sub)
        if not mask.any():
            continue
        tex = texs[mat]
        th, tw = tex.shape[:2]
        u = w0 * uv[0, 0] + w1 * uv[1, 0] + w2 * uv[2, 0]
        v = w0 * uv[0, 1] + w1 * uv[1, 1] + w2 * uv[2, 1]
        tx = np.clip((u % 1.0) * tw, 0, tw - 1).astype(int)
        ty = np.clip((v % 1.0) * th, 0, th - 1).astype(int)
        col = tex[ty, tx].copy()
        if light:
            nrm = normals.mean(0)
            nrm = nrm / (np.linalg.norm(nrm) + 1e-9)
            shade = 0.55 + 0.45 * abs(float(nrm @ light_dir))
            col[..., :3] *= shade
        col[..., 3] = 1.0
        region = img[y0:y1 + 1, x0:x1 + 1]
        region[mask] = col[mask]
        sub[mask] = z[mask]
    return Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8), "RGBA")


def main():
    preview_dir = sys.argv[1] if len(sys.argv) > 1 else None
    only = set(sys.argv[2:])
    results = {}
    for name, cfg in MODELS.items():
        if only and name not in only:
            continue
        if cfg["src"].endswith(".obj"):
            meshes, images = load_obj_parts(os.path.join(SRC, cfg["src"]), cfg["mats"])
        else:
            meshes, images = load_parts(os.path.join(SRC, cfg["src"]), cfg["parts"])
        if cfg.get("tex_file"):
            replacement = Image.open(os.path.join(SRC, cfg["tex_file"])).convert("RGBA")
            images = {m: replacement for m in images}
        tex_map, tris, (lo, hi), small = write_obj(name, meshes, images, cfg)
        results[name] = {"textures": tex_map, "min": lo.round(3).tolist(), "max": hi.round(3).tolist()}
        # A rendered inventory icon, for items that show their 3D model in the inventory too.
        if cfg.get("icon", True):
            view_lo, view_hi = min(lo[0], lo[1]), max(hi[0], hi[1])
            pad = (view_hi - view_lo) * 0.04
            icon = render(tris, small, 256, view_lo - pad, view_hi + pad).resize((32, 32), Image.LANCZOS)
            outline_icon(icon).save(os.path.join(ICON_DIR, name + "_icon.png"))
        if preview_dir:
            render(tris, small, 384, -0.25, max(1.25, float(max(hi[0], hi[1])) + 0.1)).save(
                os.path.join(preview_dir, name + "_preview.png"))
        print(f"{name}: {sum(len(m.faces) for _, m, _ in meshes)} triangles, textures {list(tex_map.values())}, "
              f"bounds {results[name]['min']} .. {results[name]['max']}")
    return results


if __name__ == "__main__":
    main()
