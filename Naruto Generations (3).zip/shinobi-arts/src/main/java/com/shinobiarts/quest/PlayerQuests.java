package com.shinobiarts.quest;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One player's quests: the random hourly/daily/weekly/monthly ones (rerolled when their period changes) and
 * their progress on their village's Kage quests. Saved with the player in the part of their data Forge keeps
 * through death. Not synced: the quest board is sent when it's opened.
 */
public final class PlayerQuests {
    public static final int OFFERED = 0, ACCEPTED = 1, COMPLETE = 2, CLAIMED = 3, DECLINED = 4;
    private static final String KEY = "shinobiarts_quests";

    public static final class Entry {
        public final String id;
        public int status;
        public int progress;

        Entry(String id, int status, int progress) {
            this.id = id;
            this.status = status;
            this.progress = progress;
        }
    }

    private final ServerPlayer player;
    private final CompoundTag root;

    private PlayerQuests(ServerPlayer player, CompoundTag root) {
        this.player = player;
        this.root = root;
    }

    public static PlayerQuests of(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(Player.PERSISTED_NBT_TAG, Tag.TAG_COMPOUND)) data.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = data.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(KEY, Tag.TAG_COMPOUND)) persisted.put(KEY, new CompoundTag());
        PlayerQuests q = new PlayerQuests(player, persisted.getCompound(KEY));
        q.refresh();
        return q;
    }

    // ---------------------------------------------------------------- random quests

    /** Rerolls any period whose hour/day/week/month has changed. */
    public void refresh() {
        LocalDateTime now = LocalDateTime.now();
        CompoundTag periods = root.getCompound("Periods");
        for (QuestPeriod period : QuestPeriod.values()) {
            CompoundTag p = periods.getCompound(period.id());
            String key = period.key(now);
            if (!key.equals(p.getString("Key")) || p.getList("Quests", Tag.TAG_COMPOUND).size() != Math.min(period.count(), QuestDefs.pool(period).size())) {
                List<QuestDefs.QuestDef> pool = new ArrayList<>(QuestDefs.pool(period));
                Collections.shuffle(pool, new java.util.Random(player.getRandom().nextLong()));
                ListTag list = new ListTag();
                for (int i = 0; i < Math.min(period.count(), pool.size()); i++) list.add(entryTag(new Entry(pool.get(i).id(), OFFERED, 0)));
                p = new CompoundTag();
                p.putString("Key", key);
                p.put("Quests", list);
                periods.put(period.id(), p);
            }
        }
        root.put("Periods", periods);
    }

    public List<Entry> quests(QuestPeriod period) {
        List<Entry> out = new ArrayList<>();
        for (Tag t : root.getCompound("Periods").getCompound(period.id()).getList("Quests", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            out.add(new Entry(c.getString("Id"), c.getInt("Status"), c.getInt("Progress")));
        }
        return out;
    }

    public void setQuests(QuestPeriod period, List<Entry> entries) {
        CompoundTag periods = root.getCompound("Periods");
        CompoundTag p = periods.getCompound(period.id());
        ListTag list = new ListTag();
        for (Entry e : entries) list.add(entryTag(e));
        p.put("Quests", list);
        periods.put(period.id(), p);
        root.put("Periods", periods);
    }

    private static CompoundTag entryTag(Entry e) {
        CompoundTag c = new CompoundTag();
        c.putString("Id", e.id);
        c.putInt("Status", e.status);
        c.putInt("Progress", e.progress);
        return c;
    }

    // ---------------------------------------------------------------- kage quests

    public int kageStatus(String village, int questId) {
        CompoundTag k = root.getCompound("Kage").getCompound(village + ":" + questId);
        return k.contains("Status") ? k.getInt("Status") : OFFERED;
    }

    public void setKageStatus(String village, int questId, int status) {
        CompoundTag kage = root.getCompound("Kage");
        CompoundTag k = new CompoundTag();
        k.putInt("Status", status);
        kage.put(village + ":" + questId, k);
        root.put("Kage", kage);
    }

    // ---------------------------------------------------------------- progress

    /** Counts a kill/catch toward every accepted quest of that type; announces any that complete. */
    public void addProgress(QuestType type, int amount) {
        for (QuestPeriod period : QuestPeriod.values()) {
            List<Entry> entries = quests(period);
            boolean changed = false;
            for (Entry e : entries) {
                QuestDefs.QuestDef def = QuestDefs.byId(e.id);
                if (def == null || def.type() != type || e.status != ACCEPTED) continue;
                e.progress = Math.min(def.count(), e.progress + amount);
                if (e.progress >= def.count()) {
                    e.status = COMPLETE;
                    announce(def);
                }
                changed = true;
            }
            if (changed) setQuests(period, entries);
        }
    }

    /** Gather quests complete by themselves once you're carrying enough. */
    public void checkGather() {
        for (QuestPeriod period : QuestPeriod.values()) {
            List<Entry> entries = quests(period);
            boolean changed = false;
            for (Entry e : entries) {
                QuestDefs.QuestDef def = QuestDefs.byId(e.id);
                if (def == null || def.type() != QuestType.GATHER || e.status != ACCEPTED) continue;
                if (QuestItems.count(player.getInventory(), def.target()) >= def.count()) {
                    e.status = COMPLETE;
                    e.progress = def.count();
                    announce(def);
                    changed = true;
                }
            }
            if (changed) setQuests(period, entries);
        }
    }

    private void announce(QuestDefs.QuestDef def) {
        player.sendSystemMessage(Component.translatable("message.shinobiarts.quest_complete", QuestBoard.title(def.type(), def.count(), def.target()))
                .withStyle(ChatFormatting.GOLD));
    }
}
