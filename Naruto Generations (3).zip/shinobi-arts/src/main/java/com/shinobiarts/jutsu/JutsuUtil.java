package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.entity.ShadowClone;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Targeting, movement, particle and sound helpers shared by all jutsu. */
public final class JutsuUtil {
    private JutsuUtil() {}

    public static float dmg(float base) {
        return base * Config.f(Config.DAMAGE_MULTIPLIER) * castMultiplier;
    }

    /** The last jutsu each player cast (by UUID), for death messages: damage dealt later still names it. */
    private static final java.util.Map<java.util.UUID, String> LAST_JUTSU = new java.util.concurrent.ConcurrentHashMap<>();

    /** Remembers the jutsu a player is casting (called just before it goes off). */
    public static void noteCast(Entity caster, Jutsu jutsu) {
        if (caster != null) LAST_JUTSU.put(caster.getUUID(), jutsu.id());
    }

    /** The jutsu that player (or that shadow clone's owner) cast last, or null. */
    @Nullable
    public static String lastJutsu(@Nullable Entity caster) {
        if (caster == null) return null;
        if (caster instanceof ShadowClone clone && clone.getOwnerUUID() != null) return LAST_JUTSU.get(clone.getOwnerUUID());
        return LAST_JUTSU.get(caster.getUUID());
    }

    /** The upgrade bonus of the jutsu being cast right now (server thread only), applied by every dmg() call. */
    private static float castMultiplier = 1f;

    /** How charged the jutsu being cast right now is: 0 (a tap) to 1 (full), or -1 when it wasn't charged. */
    private static float castCharge = -1f;

    /** Performs a cast with the jutsu's upgrade bonus applied to the damage it deals. */
    public static boolean withUpgrade(float multiplier, java.util.function.BooleanSupplier cast) {
        return withCast(multiplier, -1f, cast);
    }

    /** Performs a cast with its damage multiplier and how charged it is (-1 = not charged). */
    public static boolean withCast(float multiplier, float charge, java.util.function.BooleanSupplier cast) {
        float before = castMultiplier, chargeBefore = castCharge;
        castMultiplier = multiplier;
        castCharge = charge;
        try {
            return cast.getAsBoolean();
        } finally {
            castMultiplier = before;
            castCharge = chargeBefore;
        }
    }

    /**
     * Size of a charged jutsu (e.g. the Great Fireball): {@code small} for a quick tap, {@code large} at full charge,
     * and halfway between when the jutsu wasn't charged at all (charging off in the config).
     */
    public static float chargeSize(float small, float large) {
        float t = castCharge < 0 ? 0.5f : Math.min(1f, castCharge);
        return small + (large - small) * t;
    }

    /** The upgrade and clan bonus of a player's jutsu, for damage dealt later (Rasengan's hit, shadow clones' copies). */
    public static float upgradeBonus(@Nullable Entity owner, String jutsuId) {
        if (!(owner instanceof net.minecraft.world.entity.player.Player player)) return 1f;
        com.shinobiarts.ninja.NinjaData d = com.shinobiarts.ninja.NinjaData.get(player);
        Jutsu jutsu = Jutsus.get(jutsuId);
        return d == null || jutsu == null ? 1f : d.jutsuBonus(jutsu);
    }

    /** Whether jutsu may place fire / break blocks here (config + mobGriefing gamerule). */
    public static boolean griefing(Level level, @Nullable Entity cause) {
        if (!Config.b(Config.JUTSU_GRIEFING)) return false;
        return ForgeEventFactory.getMobGriefingEvent(level, cause);
    }

    /** True if {@code target} is something {@code owner}'s jutsu should hit. */
    public static boolean isValidTarget(@Nullable Entity owner, Entity target) {
        if (!(target instanceof LivingEntity living) || !living.isAlive() || target.isSpectator()) return false;
        if (target instanceof ArmorStand) return false;
        if (owner == null) return true;
        if (target == owner) return false;
        if (target instanceof ShadowClone clone && owner.getUUID().equals(clone.getOwnerUUID())) return false;
        if (target instanceof TamableAnimal pet && owner instanceof LivingEntity livingOwner && pet.isOwnedBy(livingOwner)) return false;
        if (owner.isAlliedTo(target)) return false;
        if (target instanceof Player victim && owner instanceof Player attacker && !attacker.canHarmPlayer(victim)) return false;
        return true;
    }

    // ---------------------------------------------------------------- targeting

    public static BlockHitResult rayBlock(Player player, double range) {
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(player.getLookAngle().scale(range));
        return player.level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
    }

    /** First valid living entity along the player's line of sight, stopping at walls. */
    @Nullable
    public static LivingEntity rayTarget(Player player, double range) {
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(player.getLookAngle().scale(range));
        BlockHitResult blockHit = player.level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (blockHit.getType() != HitResult.Type.MISS) end = blockHit.getLocation();

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        AABB search = new AABB(start, end).inflate(1.0);
        for (Entity e : player.level().getEntities(player, search, cand -> isValidTarget(player, cand))) {
            Optional<Vec3> hit = e.getBoundingBox().inflate(0.4).clip(start, end);
            if (hit.isPresent()) {
                double d = start.distanceToSqr(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = (LivingEntity) e;
                }
            }
        }
        return best;
    }

    /** Valid targets inside a cone in front of the player. */
    public static List<LivingEntity> inCone(Player player, double range, double halfAngleDeg) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        double minDot = Math.cos(Math.toRadians(halfAngleDeg));
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(range), cand -> isValidTarget(player, cand))) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range) continue;
            if (dist < 1.5 || (to.scale(1.0 / dist).dot(look) >= minDot && player.hasLineOfSight(e))) out.add(e);
        }
        return out;
    }

    /** Valid targets within a radius of a point. */
    public static List<LivingEntity> inRadius(Level level, @Nullable Entity owner, Vec3 center, double radius) {
        AABB box = new AABB(center, center).inflate(radius);
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, cand -> isValidTarget(owner, cand))) {
            if (e.getBoundingBox().getCenter().distanceToSqr(center) <= radius * radius) out.add(e);
        }
        return out;
    }

    /** A random direction within a cone around {@code axis}. */
    public static Vec3 randomConeDir(Vec3 axis, double halfAngleDeg, RandomSource random) {
        double spread = Math.tan(Math.toRadians(halfAngleDeg));
        for (int i = 0; i < 10; i++) {
            Vec3 v = new Vec3(random.nextDouble() * 2 - 1, random.nextDouble() * 2 - 1, random.nextDouble() * 2 - 1);
            if (v.lengthSqr() > 1.0) continue;
            Vec3 perp = v.subtract(axis.scale(v.dot(axis)));
            return axis.add(perp.scale(spread)).normalize();
        }
        return axis;
    }

    /** Horizontal unit vector pointing to the player's right. */
    public static Vec3 right(Player player) {
        Vec3 look = player.getLookAngle();
        Vec3 r = new Vec3(-look.z, 0, look.x);
        return r.lengthSqr() < 1e-6 ? new Vec3(1, 0, 0) : r.normalize();
    }

    // ---------------------------------------------------------------- movement

    /** Adds velocity to an entity and makes sure players' clients receive it. */
    public static void push(Entity entity, Vec3 velocity) {
        entity.setDeltaMovement(entity.getDeltaMovement().add(velocity));
        entity.hasImpulse = true;
        entity.hurtMarked = true;
    }

    /** Finds a spot near {@code feet} where the entity fits, or null. */
    @Nullable
    public static Vec3 findSafe(Entity entity, Vec3 feet) {
        double[] offsets = {0, 0.5, 1.0, -0.5, -1.0, 1.5};
        for (double dy : offsets) {
            Vec3 pos = feet.add(0, dy, 0);
            AABB box = entity.getBoundingBox().move(pos.x - entity.getX(), pos.y - entity.getY(), pos.z - entity.getZ());
            if (!entity.level().noCollision(entity, box)) continue;
            if (entity.level().getFluidState(BlockPos.containing(pos)).is(FluidTags.LAVA)) continue;
            return pos;
        }
        return null;
    }

    public static void teleport(Entity entity, Vec3 pos) {
        if (entity instanceof ServerPlayer sp) {
            sp.stopRiding();
            sp.connection.teleport(pos.x, pos.y, pos.z, sp.getYRot(), sp.getXRot());
        } else {
            entity.teleportTo(pos.x, pos.y, pos.z);
        }
        entity.resetFallDistance();
    }

    // ---------------------------------------------------------------- effects

    public static void particles(ServerLevel level, ParticleOptions type, Vec3 pos, int count, double spread, double speed) {
        level.sendParticles(type, pos.x, pos.y, pos.z, count, spread, spread, spread, speed);
    }

    /** Particles flying out along a cone (each one gets its own velocity). */
    public static void stream(ServerLevel level, ParticleOptions type, Vec3 origin, Vec3 axis, double halfAngleDeg,
                              int count, double minSpeed, double maxSpeed) {
        RandomSource r = level.getRandom();
        for (int i = 0; i < count; i++) {
            Vec3 dir = randomConeDir(axis, halfAngleDeg, r);
            double speed = minSpeed + r.nextDouble() * (maxSpeed - minSpeed);
            level.sendParticles(type, origin.x, origin.y, origin.z, 0, dir.x, dir.y, dir.z, speed);
        }
    }

    /** Evenly spaced particles along a line. */
    public static void line(ServerLevel level, ParticleOptions type, Vec3 from, Vec3 to, double spacing, int perPoint, double spread) {
        Vec3 delta = to.subtract(from);
        double length = delta.length();
        if (length < 1e-3) return;
        Vec3 step = delta.scale(spacing / length);
        Vec3 p = from;
        for (double d = 0; d <= length; d += spacing) {
            level.sendParticles(type, p.x, p.y, p.z, perPoint, spread, spread, spread, 0.0);
            p = p.add(step);
        }
    }

    public static void sound(Level level, Vec3 pos, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, pos.x, pos.y, pos.z, sound, SoundSource.PLAYERS, volume, pitch);
    }
}
