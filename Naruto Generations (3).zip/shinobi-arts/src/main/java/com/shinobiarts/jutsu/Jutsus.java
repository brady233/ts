package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.shinobiarts.ninja.ChakraNature.BONE;
import static com.shinobiarts.ninja.ChakraNature.EARTH;
import static com.shinobiarts.ninja.ChakraNature.ICE;
import static com.shinobiarts.ninja.ChakraNature.MAGNET;
import static com.shinobiarts.ninja.ChakraNature.SEALING;
import static com.shinobiarts.ninja.ChakraNature.WOOD;
import static com.shinobiarts.ninja.ChakraNature.FIRE;
import static com.shinobiarts.ninja.ChakraNature.LIGHTNING;
import static com.shinobiarts.ninja.ChakraNature.NONE;
import static com.shinobiarts.ninja.ChakraNature.WATER;
import static com.shinobiarts.ninja.ChakraNature.WIND;
import static com.shinobiarts.ninja.ChakraNature.YIN_YANG;
import static com.shinobiarts.jutsu.JutsuRank.A;
import static com.shinobiarts.jutsu.JutsuRank.B;
import static com.shinobiarts.jutsu.JutsuRank.C;
import static com.shinobiarts.jutsu.JutsuRank.D;
import static com.shinobiarts.jutsu.JutsuRank.S;

/**
 * Every jutsu in the mod. To add one: register it here, implement its effect in {@link JutsuEffects},
 * then add its name, description and recipe to tools/make_resources.py and run it.
 * A jutsu goes into the slots of its nature's release; clan and non-elemental jutsu go into Ninjutsu.
 * Cooldowns are in ticks (20 ticks = 1 second).
 */
public final class Jutsus {
    private static final Map<String, Jutsu> BY_ID = new LinkedHashMap<>();
    private static final Collection<Jutsu> ALL = Collections.unmodifiableCollection(BY_ID.values());

    // Ranks follow the show where it gives one (Narutopedia / databooks); unranked jutsu are placed by strength.
    // Each jutsu's chakra cost, damage, cooldown and charge are in its own section of Jutsus.toml (the cooldowns here are the
    // defaults). Chakra costs default by rank: D 18%, C 22%, B 27%, A 33%, S 40% of max chakra.
    //                                       id                    nature     clan          rank cooldown needs eyes
    // Fire Release
    public static final Jutsu FIREBALL          = reg("fireball",          FIRE,      null,         C,    30,  false, JutsuEffects::fireball);
    public static final Jutsu PHOENIX_FLOWER    = reg("phoenix_flower",    FIRE,      null,         C,    40,  false, JutsuEffects::phoenixFlower);
    public static final Jutsu FIRE_ANNIHILATION = reg("fire_annihilation", FIRE,      null,         B,   120,  false, JutsuEffects::fireAnnihilation);
    public static final Jutsu MAJESTIC_FLAME    = reg("majestic_destroyer_flame", FIRE, null,       S,   400,  false, JutsuEffects::majesticDestroyerFlame);
    // Water Release
    public static final Jutsu WATER_BULLET      = reg("water_bullet",      WATER,     null,         D,    15,  false, JutsuEffects::waterBullet);
    public static final Jutsu WATER_PRISON      = reg("water_prison",      WATER,     null,         C,   160,  false, JutsuEffects::waterPrison);
    public static final Jutsu WATER_SHARK       = reg("water_shark",       WATER,     null,         B,   140,  false, JutsuEffects::waterShark);
    public static final Jutsu WATER_DRAGON      = reg("water_dragon",      WATER,     null,         B,   100,  false, JutsuEffects::waterDragon);
    // Wind Release
    public static final Jutsu GALE_PALM         = reg("gale_palm",         WIND,      null,         C,    20,  false, JutsuEffects::galePalm);
    public static final Jutsu VACUUM_BLADE      = reg("vacuum_blade",      WIND,      null,         B,    30,  false, JutsuEffects::vacuumBlade);
    public static final Jutsu GREAT_BREAKTHROUGH= reg("great_breakthrough",WIND,      null,         C,   100,  false, JutsuEffects::greatBreakthrough);
    public static final Jutsu RASENSHURIKEN     = reg("rasenshuriken",     WIND,      null,         S,   300,  false, JutsuEffects::rasenshuriken);
    // Lightning Release
    public static final Jutsu LIGHTNING_ARMOR   = reg("lightning_armor",   LIGHTNING, null,         A,   480,  false, JutsuEffects::lightningArmor);
    public static final Jutsu CHIDORI           = reg("chidori",           LIGHTNING, null,         A,    80,  false, JutsuEffects::chidori);
    public static final Jutsu THUNDER_STRIKE    = reg("thunder_strike",    LIGHTNING, null,         A,   150,  false, JutsuEffects::thunderStrike);
    // Earth Release
    public static final Jutsu EARTH_WALL        = reg("earth_wall",        EARTH,     null,         B,   100,  false, JutsuEffects::earthWall);
    public static final Jutsu ROCK_ARMOR        = reg("rock_armor",        EARTH,     null,         B,   480,  false, JutsuEffects::rockArmor);
    public static final Jutsu EARTH_SPIKES      = reg("earth_spikes",      EARTH,     null,         B,    50,  false, JutsuEffects::earthSpikes);
    // Yin Yang Release: Yin illusions (stronger with Genjutsu) and Yang healing (stronger with Medical)
    public static final Jutsu HELL_VIEWING      = reg("hell_viewing",      YIN_YANG,       null,         D,   100,  false, JutsuEffects::hellViewing);
    public static final Jutsu MIND_FOG          = reg("mind_fog",          YIN_YANG,       null,         C,   200,  false, JutsuEffects::mindFog);
    public static final Jutsu MYSTICAL_PALM     = reg("mystical_palm",     YIN_YANG,      null,         A,   100,  false, JutsuEffects::mysticalPalm);
    public static final Jutsu VITALITY_SURGE    = reg("vitality_surge",    YIN_YANG,      null,         S,   480,  false, JutsuEffects::vitalitySurge);
    // Non-elemental (Ninjutsu release)
    public static final Jutsu SUBSTITUTION      = reg("substitution",      NONE,      null,         D,  1200,  false, JutsuEffects::substitution);
    public static final Jutsu BODY_FLICKER      = reg("body_flicker",      NONE,      null,         D,    30,  false, JutsuEffects::bodyFlicker);
    public static final Jutsu SHADOW_CLONE      = reg("shadow_clone",      NONE,      null,         B,   200,  false, JutsuEffects::shadowClone);
    public static final Jutsu MULTI_SHADOW_CLONE= reg("multi_shadow_clone",NONE,      null,         A,   600,  false, JutsuEffects::multiShadowClone);
    public static final Jutsu RASENGAN          = reg("rasengan",          NONE,      null,         A,   100,  false, JutsuEffects::rasengan);
    // Clan techniques. (Amaterasu is no longer a scroll: it's Jutsu 1 of the Itachi, Sasuke and Eternal Mangekyou.)
    public static final Jutsu SHADOW_POSSESSION = reg("shadow_possession", NONE,      Clan.NARA,    C,   180,  false, JutsuEffects::shadowPossession);
    public static final Jutsu MIND_TRANSFER     = reg("mind_body_transfer", NONE,     Clan.YAMANAKA, B,  600,  false, JutsuEffects::mindBodyTransfer);
    public static final Jutsu PALM_ROTATION     = reg("palm_rotation",     NONE,      Clan.HYUGA,   A,   100,  false, JutsuEffects::palmRotation);

    // Clan releases: only their clan can learn them (the clan comes from the release). The first of each is given
    // with the release when the clan is locked in; the other two are scrolls. Effects are in ClanJutsu.
    // Wood Release (Senju)
    public static final Jutsu WOOD_BINDING      = reg("wood_binding",      WOOD,      null,         C,   200,  false, ClanJutsu::woodBinding);
    public static final Jutsu WOOD_DOME         = reg("wood_dome",         WOOD,      null,         B,   600,  false, ClanJutsu::woodDome);
    public static final Jutsu DEEP_FOREST       = reg("deep_forest",       WOOD,      null,         S,  1200,  false, ClanJutsu::deepForest);
    // Ice Release (Yuki)
    public static final Jutsu ICE_NEEDLES       = reg("ice_needles",       ICE,       null,         C,    40,  false, ClanJutsu::iceNeedles);
    public static final Jutsu ICE_PRISON        = reg("ice_prison",        ICE,       null,         B,   240,  false, ClanJutsu::icePrison);
    public static final Jutsu ICE_MIRRORS       = reg("ice_mirrors",       ICE,       null,         A,   600,  false, ClanJutsu::iceMirrors);
    // Magnet Release (Kazekage)
    public static final Jutsu IRON_SAND_DRIZZLE = reg("iron_sand_drizzle", MAGNET,    null,         C,    60,  false, ClanJutsu::ironSandDrizzle);
    public static final Jutsu IRON_SAND_COFFIN  = reg("iron_sand_coffin",  MAGNET,    null,         B,   240,  false, ClanJutsu::ironSandCoffin);
    public static final Jutsu IRON_SAND_WORLD   = reg("iron_sand_world",   MAGNET,    null,         A,   400,  false, ClanJutsu::ironSandWorld);
    // Bone (Kaguya)
    public static final Jutsu FINGER_BULLETS    = reg("finger_bullets",    BONE,      null,         C,    40,  false, ClanJutsu::fingerBullets);
    public static final Jutsu WILLOW_DANCE      = reg("willow_dance",      BONE,      null,         B,   600,  false, ClanJutsu::willowDance);
    public static final Jutsu SEEDLING_FERN     = reg("seedling_fern",     BONE,      null,         A,   600,  false, ClanJutsu::seedlingFern);
    // Sealing (Uzumaki)
    public static final Jutsu BARRIER           = reg("barrier",           SEALING,   null,         C,   400,  false, ClanJutsu::barrier);
    public static final Jutsu ADAMANTINE_CHAINS = reg("adamantine_chains", SEALING,   null,         B,   300,  false, ClanJutsu::adamantineChains);
    public static final Jutsu FIVE_ELEMENTS_SEAL= reg("five_elements_seal",SEALING,   null,         A,   900,  false, ClanJutsu::fiveElementsSeal);

    private static Jutsu reg(String id, ChakraNature nature, @Nullable Clan clan, JutsuRank rank, int cooldown, boolean needsDojutsu, Jutsu.Action action) {
        Jutsu jutsu = new Jutsu(id, nature, clan, rank, cooldown, needsDojutsu, action);
        if (BY_ID.put(id, jutsu) != null) throw new IllegalStateException("Duplicate jutsu id " + id);
        return jutsu;
    }

    @Nullable
    public static Jutsu get(String id) {
        return BY_ID.get(id);
    }

    public static Collection<Jutsu> all() {
        return ALL;
    }

    /** The first jutsu of a release (the one a clan release starts with), or null. */
    @Nullable
    public static Jutsu firstOf(ChakraNature release) {
        for (Jutsu j : ALL) {
            if (j.nature() == release) return j;
        }
        return null;
    }

    /** Jutsu that deal damage: the ones Jutsu Points can upgrade. */
    private static final java.util.Set<String> DAMAGING = java.util.Set.of(
            "fireball", "phoenix_flower", "fire_annihilation", "majestic_destroyer_flame", "water_bullet", "water_prison", "water_shark", "water_dragon",
            "gale_palm", "vacuum_blade", "great_breakthrough", "rasenshuriken", "chidori", "thunder_strike",
            "earth_spikes", "hell_viewing", "rasengan", "palm_rotation",
            "deep_forest", "ice_needles", "ice_mirrors", "iron_sand_drizzle", "iron_sand_coffin", "iron_sand_world",
            "finger_bullets", "seedling_fern");

    public static boolean upgradeable(Jutsu jutsu) {
        return DAMAGING.contains(jutsu.id());
    }

    /** Position in registration order: how the client names a jutsu in packets (same on both sides). */
    public static int index(Jutsu jutsu) {
        int i = 0;
        for (Jutsu j : ALL) {
            if (j == jutsu) return i;
            i++;
        }
        return -1;
    }

    @Nullable
    public static Jutsu byIndex(int index) {
        int i = 0;
        for (Jutsu j : ALL) {
            if (i++ == index) return j;
        }
        return null;
    }

    private Jutsus() {}
}
