package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.Susanoo;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /susanoo color <part|all> <colour>   colour your own Susanoo: a preset (purple, blue, light_blue, red, green, yellow,
 *                                       orange, white, cyan, pink) or any #RRGGBB. Parts: body, armor, weapon, eyes,
 *                                       chakra (the rim light and glow), aura. "all" with a preset sets the whole look.
 * /susanoo color reset                 back to purple
 * /susanoo colors                      shows your colours
 */
public final class SusanooCommand {
    private SusanooCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        List<String> parts = new ArrayList<>(List.of(NinjaData.SUSANOO_PARTS));
        parts.add("all");
        dispatcher.register(Commands.literal("susanoo")
                .then(Commands.literal("colors").executes(SusanooCommand::show))
                .then(Commands.literal("color")
                        .then(Commands.literal("reset").executes(SusanooCommand::reset))
                        .then(Commands.argument("part", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(parts, b))
                                .then(Commands.argument("color", StringArgumentType.greedyString())
                                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Susanoo.PRESETS.keySet(), b))
                                        .executes(SusanooCommand::set)))));
    }

    private static int set(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(p);
        if (d == null) return 0;
        String part = StringArgumentType.getString(ctx, "part").toLowerCase(Locale.ROOT);
        String value = StringArgumentType.getString(ctx, "color").trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        int index = List.of(NinjaData.SUSANOO_PARTS).indexOf(part);
        if (index < 0 && !part.equals("all")) {
            ctx.getSource().sendFailure(Component.translatable("command.shinobiarts.susanoo_part", String.join(", ", NinjaData.SUSANOO_PARTS)));
            return 0;
        }
        int[] preset = Susanoo.presetColors(value);
        if (part.equals("all")) {
            if (preset != null) {
                d.setSusanooColors(preset);
            } else {
                Integer rgb = hex(value);
                if (rgb == null) return bad(ctx);
                int[] all = {rgb, rgb, 0xFFFFFF, 0xFFFFFF, rgb, rgb};
                d.setSusanooColors(all);
            }
        } else {
            Integer rgb = preset != null ? (index == 1 ? preset[1] : index == 2 || index == 3 ? Susanoo.PRESETS.get(value)[0] : preset[0]) : hex(value);
            if (rgb == null) return bad(ctx);
            d.setSusanooColor(index, rgb);
        }
        Susanoo.applyColors(p);
        ModNetwork.sync(p);
        return show(ctx);
    }

    private static int bad(CommandContext<CommandSourceStack> ctx) {
        ctx.getSource().sendFailure(Component.translatable("command.shinobiarts.susanoo_color", String.join(", ", Susanoo.PRESETS.keySet())));
        return 0;
    }

    private static Integer hex(String s) {
        String h = s.startsWith("#") ? s.substring(1) : s;
        if (!h.matches("[0-9a-f]{6}")) return null;
        return Integer.parseInt(h, 16);
    }

    private static int reset(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(p);
        if (d == null) return 0;
        d.setSusanooColors(NinjaData.defaultSusanooColors());
        Susanoo.applyColors(p);
        ModNetwork.sync(p);
        return show(ctx);
    }

    private static int show(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(p);
        if (d == null) return 0;
        int[] c = d.getSusanooColors();
        MutableComponent msg = Component.translatable("command.shinobiarts.susanoo_colors").withStyle(ChatFormatting.LIGHT_PURPLE);
        for (int i = 0; i < c.length; i++) {
            msg.append(Component.literal("\n " + NinjaData.SUSANOO_PARTS[i] + ": ").withStyle(ChatFormatting.GRAY))
                    .append(Component.literal("██ " + String.format("#%06X", c[i])).withStyle(Style.EMPTY.withColor(TextColor.fromRgb(c[i]))));
        }
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }
}
