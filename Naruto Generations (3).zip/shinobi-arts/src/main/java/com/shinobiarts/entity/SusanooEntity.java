package com.shinobiarts.entity;

import com.shinobiarts.ninja.Susanoo;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.function.IntPredicate;

/**
 * A player's Susanoo: a giant chakra body that stands around them (stages 1-4) or carries them in its head (the
 * Perfect Susanoo). It has no mind of its own: Susanoo.java moves it with its owner every tick, and its health lives
 * in the owner's ninja data. This entity is what other players and creatures can hit, and what the client draws
 * (client/SusanooRenderer). Never saved: it's summoned again as needed.
 */
public class SusanooEntity extends Entity {
    private static final EntityDataAccessor<Integer> OWNER = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> STAGE = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Byte> ACTION = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Integer> ACTION_SEQ = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> BLOCKING = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> COLOR_BODY = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> COLOR_ARMOR = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> COLOR_WEAPON = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> COLOR_EYES = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> COLOR_CHAKRA = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> COLOR_AURA = SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);
    @SuppressWarnings("unchecked")
    private static final EntityDataAccessor<Integer>[] COLORS = new EntityDataAccessor[]{COLOR_BODY, COLOR_ARMOR, COLOR_WEAPON, COLOR_EYES, COLOR_CHAKRA, COLOR_AURA};

    /** Actions the client animates (keyframes in assets/shinobiarts/susanoo/data.json). */
    public static final byte NONE = 0, SWING_1 = 1, SWING_2 = 2, SWING_3 = 3, SPECIAL = 4;

    /** Hitbox width and height per stage (the Perfect Susanoo's wings left out). */
    private static final float[][] SIZE = {{1, 1}, {3.0f, 4.3f}, {5.0f, 7.3f}, {5.5f, 10.2f}, {7.5f, 14.1f}, {9.0f, 24.3f}};

    /** Set on the client: whether an entity id is the local player (so you can't target your own Susanoo). */
    public static IntPredicate isLocalPlayer = id -> false;

    // client-side animation clocks (in this entity's ticks)
    public int actionStart = -100;
    public int summonStart;
    public float blockWeight, blockWeightO;
    private int lastSeq;

    public SusanooEntity(EntityType<? extends SusanooEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(OWNER, -1);
        entityData.define(STAGE, 1);
        entityData.define(ACTION, NONE);
        entityData.define(ACTION_SEQ, 0);
        entityData.define(BLOCKING, false);
        int[] def = com.shinobiarts.ninja.NinjaData.defaultSusanooColors();
        for (int i = 0; i < COLORS.length; i++) entityData.define(COLORS[i], def[i]);
    }

    // ---------------------------------------------------------------- data

    public int getOwnerId() {
        return entityData.get(OWNER);
    }

    public void setOwner(Player owner) {
        entityData.set(OWNER, owner.getId());
    }

    @Nullable
    public Player getOwner() {
        Entity e = level().getEntity(getOwnerId());
        return e instanceof Player p ? p : null;
    }

    public int getStage() {
        return entityData.get(STAGE);
    }

    public void setStage(int stage) {
        entityData.set(STAGE, Math.max(1, Math.min(5, stage)));
    }

    public byte getAction() {
        return entityData.get(ACTION);
    }

    /** Plays an action (a swing, the special) from its start. */
    public void playAction(byte action) {
        entityData.set(ACTION, action);
        entityData.set(ACTION_SEQ, entityData.get(ACTION_SEQ) + 1);
    }

    public boolean isBlocking() {
        return entityData.get(BLOCKING);
    }

    public void setBlocking(boolean b) {
        if (b != isBlocking()) entityData.set(BLOCKING, b);
    }

    /** Body, armor, weapon, eyes, chakra, aura. */
    public int getColor(int part) {
        return entityData.get(COLORS[part]);
    }

    public void setColors(int[] colors) {
        for (int i = 0; i < COLORS.length && i < colors.length; i++) {
            if (entityData.get(COLORS[i]) != colors[i]) entityData.set(COLORS[i], colors[i]);
        }
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (STAGE.equals(key)) {
            refreshDimensions();
            summonStart = tickCount;
        } else if (ACTION_SEQ.equals(key)) {
            int seq = entityData.get(ACTION_SEQ);
            if (seq != lastSeq) {
                lastSeq = seq;
                actionStart = tickCount;
            }
        }
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        float[] s = SIZE[Math.max(1, Math.min(5, getStage()))];
        return EntityDimensions.scalable(s[0], s[1]);
    }

    // ---------------------------------------------------------------- behaviour

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            blockWeightO = blockWeight;
            blockWeight += ((isBlocking() ? 1f : 0f) - blockWeight) * 0.35f;
            // a little of its chakra drifting up around the base
            if (random.nextInt(3) == 0) {
                int c = getColor(5);
                float w = getBbWidth() * 0.45f;
                level().addParticle(new DustParticleOptions(new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f), 1.6f),
                        getX() + (random.nextDouble() - 0.5) * 2 * w, getY() + random.nextDouble() * 0.6, getZ() + (random.nextDouble() - 0.5) * 2 * w,
                        0, 0.05, 0);
            }
        } else if (getOwner() == null && tickCount > 2) {
            discard(); // its owner left or died
        }
    }

    /** Hits from anyone but its owner land on its health (and its owner's blocking). */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return false;
        Player owner = getOwner();
        if (owner == null || source.getEntity() == owner) return false;
        if (!(owner instanceof ServerPlayer sp)) return false;
        return Susanoo.hitSusanoo(sp, source, amount);
    }

    @Override
    public boolean skipAttackInteraction(Entity attacker) {
        return attacker.getId() == getOwnerId();
    }

    /** Its owner's crosshair goes straight through it (they stand inside), everyone else can hit it. */
    @Override
    public boolean isPickable() {
        return !(level().isClientSide && isLocalPlayer.test(getOwnerId()));
    }

    @Override
    public boolean isAttackable() {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public void push(Entity entity) {
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 200 * 200;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return new ClientboundAddEntityPacket(this);
    }
}
