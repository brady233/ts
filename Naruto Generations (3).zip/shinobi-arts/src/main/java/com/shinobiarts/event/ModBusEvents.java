package com.shinobiarts.event;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModEntities;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModBusEvents {
    private ModBusEvents() {}

    @SubscribeEvent
    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(NinjaData.class);
    }

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.SHADOW_CLONE.get(), ShadowClone.createAttributes().build());
        event.put(ModEntities.NINJA_BANDIT.get(), com.shinobiarts.entity.NinjaBandit.createAttributes().build());
    }

    /** Ninja bandits spawn on the surface (open sky), in any light; where they spawn is set by the biome modifier JSON. */
    @SubscribeEvent
    public static void registerSpawns(net.minecraftforge.event.entity.SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.NINJA_BANDIT.get(), net.minecraft.world.entity.SpawnPlacements.Type.ON_GROUND,
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, com.shinobiarts.entity.NinjaBandit::checkSpawn,
                net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
}
