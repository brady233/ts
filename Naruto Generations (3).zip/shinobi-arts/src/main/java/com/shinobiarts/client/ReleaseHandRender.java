package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.ReleaseItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * A held release (any of them, the kekkei genkai releases too) isn't carried like an item: its emblem sits small and
 * flat on the underside of the hand, so you only see it if you look up at the hand from below.
 * <ul>
 *   <li>Third person: the arm hangs like an empty hand, and the emblem is placed by the release models' own
 *       "thirdperson" display settings (flat against the end of the arm).</li>
 *   <li>First person: your bare arm, the same as an empty hand, with the emblem on the end of the fist.</li>
 * </ul>
 * While a jutsu is charging the arm takes the usual charging pose.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ReleaseHandRender {
    private ReleaseHandRender() {}

    /** How big the emblem is: just the size of the end of the arm (4 x 4 pixels). */
    private static final float EMBLEM_SCALE = 0.26f;

    private static boolean releaseIn(Player p, InteractionHand hand) {
        return p.getItemInHand(hand).getItem() instanceof ReleaseItem;
    }

    /** Third person: an arm holding a release hangs like an empty one (unless it's charging a jutsu). */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        PlayerModel<AbstractClientPlayer> model = event.getRenderer().getModel();
        for (InteractionHand hand : InteractionHand.values()) {
            if (!releaseIn(p, hand) || (p.isUsingItem() && p.getUsedItemHand() == hand)) continue;
            if (hand == InteractionHand.MAIN_HAND && RasenganRender.age(p, event.getPartialTick()) >= 0) continue; // holding a Rasengan
            HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
            if (arm == HumanoidArm.RIGHT) model.rightArmPose = HumanoidModel.ArmPose.EMPTY;
            else model.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        }
    }

    /** First person: the bare arm (as vanilla draws an empty hand) with the emblem on the end of the fist. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        ItemStack stack = event.getItemStack();
        if (!(stack.getItem() instanceof ReleaseItem)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || player.isInvisible()) return;
        // a Rasengan (or any jutsu drawn on the fist) is drawn by its own renderer, which shows the bare hand too
        if (event.getHand() == InteractionHand.MAIN_HAND && RasenganRender.age(player, event.getPartialTick()) >= 0) return;
        if (!(mc.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer renderer)) return;
        event.setCanceled(true);
        HumanoidArm arm = event.getHand() == InteractionHand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        boolean right = arm == HumanoidArm.RIGHT;
        float f = right ? 1f : -1f;
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        // the same arm vanilla draws for an empty hand (ItemInHandRenderer.renderPlayerArm)
        float swing = event.getSwingProgress(), equip = event.getEquipProgress();
        float s1 = Mth.sqrt(swing);
        ps.translate(f * (-0.3f * Mth.sin(s1 * Mth.PI) + 0.64000005f), 0.4f * Mth.sin(s1 * (Mth.PI * 2f)) - 0.6f + equip * -0.6f,
                -0.4f * Mth.sin(swing * Mth.PI) - 0.71999997f);
        ps.mulPose(Axis.YP.rotationDegrees(f * 45f));
        ps.mulPose(Axis.YP.rotationDegrees(f * Mth.sin(s1 * Mth.PI) * 70f));
        ps.mulPose(Axis.ZP.rotationDegrees(f * Mth.sin(swing * swing * Mth.PI) * -20f));
        ps.translate(f * -1f, 3.6f, 3.5f);
        ps.mulPose(Axis.ZP.rotationDegrees(f * 120f));
        ps.mulPose(Axis.XP.rotationDegrees(200f));
        ps.mulPose(Axis.YP.rotationDegrees(f * -135f));
        ps.translate(f * 5.6f, 0f, 0f);
        if (right) renderer.renderRightHand(ps, event.getMultiBufferSource(), event.getPackedLight(), player);
        else renderer.renderLeftHand(ps, event.getMultiBufferSource(), event.getPackedLight(), player);
        // the emblem, flat on the end of the arm (arm space: +Y runs down the arm to the fist, 1 pixel = 1/16)
        ps.translate(-f * 5f / 16f, 2f / 16f, 0f);                  // the arm's pivot
        ps.translate(-f / 16f, 10.7f / 16f, 0f);                    // just past the end of the fist (and the sleeve)
        ps.mulPose(Axis.XP.rotationDegrees(-90f));                  // face out of the fist
        ps.scale(EMBLEM_SCALE, EMBLEM_SCALE, EMBLEM_SCALE);
        mc.getItemRenderer().renderStatic(player, stack, ItemDisplayContext.NONE, !right, ps, event.getMultiBufferSource(),
                player.level(), event.getPackedLight(), OverlayTexture.NO_OVERLAY, player.getId());
        ps.popPose();
    }
}
