package com.shinobiarts.client;

import com.shinobiarts.entity.SusanooEntity;
import com.shinobiarts.ninja.Susanoo;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import javax.annotation.Nullable;
import java.util.Map;

/**
 * Poses a Susanoo's bones for one frame. Each bone gets X/Y/Z angles in degrees (applied Z, then Y, then X about its
 * pivot, like Minecraft's model parts), adding up:
 * <ul>
 *   <li>breathing: a slow sway of the body and arms, the jaw working (Skeletal);</li>
 *   <li>the Perfect Susanoo: legs walking with its rider's movement, or wings beating while it flies;</li>
 *   <li>the head following where its owner looks (stages 2-4);</li>
 *   <li>the keyframed action playing (swings, the special; data.json), and the blocking pose blended in.</li>
 * </ul>
 * In model space the Susanoo faces +Z and its right side is -X: a negative X angle swings a hanging limb forward.
 */
public final class SusanooPose {
    private SusanooPose() {}

    public static Matrix4f[] bones(SusanooModel model, SusanooEntity e, @Nullable Player owner, float yaw, float partial) {
        int n = model.bones.length;
        float[][] a = new float[n][3];
        float t = e.tickCount + partial;
        int stage = model.stage;

        // breathing
        add(model, a, "body", Mth.sin(t * 0.05f) * (stage == 5 ? 0.6f : 1.2f), 0, 0);
        add(model, a, "arm_r", 0, 0, Mth.sin(t * 0.06f) * 2f);
        add(model, a, "arm_l", 0, 0, -Mth.sin(t * 0.06f) * 2f);
        add(model, a, "jaw", 3 + 3 * Mth.sin(t * 0.1f), 0, 0);

        if (stage == 5) {
            Vec3 feet = e.getPosition(partial);
            if (owner != null) feet = Susanoo.feetFor(owner, 5, owner.getPosition(partial), yaw);
            if (!SusanooRenderer.grounded(e, feet)) {               // flying: wings beat, legs hang back
                float flap = Mth.sin(t * 0.22f) * 22f;
                add(model, a, "wing_r", 0, 0, -flap);
                add(model, a, "wing_l", 0, 0, flap);
                add(model, a, "leg_r", 12, 0, 0);
                add(model, a, "leg_l", 8, 0, 0);
                add(model, a, "shin_r", 18, 0, 0);
                add(model, a, "shin_l", 22, 0, 0);
            } else {
                float idle = Mth.sin(t * 0.07f) * 3f;
                add(model, a, "wing_r", 0, 0, -idle);
                add(model, a, "wing_l", 0, 0, idle);
                if (owner != null) {
                    float pos = owner.walkAnimation.position(partial), speed = Math.min(1f, owner.walkAnimation.speed(partial));
                    float swing = Mth.sin(pos * 0.3f) * 26f * speed;
                    add(model, a, "leg_r", swing, 0, 0);
                    add(model, a, "leg_l", -swing, 0, 0);
                    add(model, a, "shin_r", Math.max(0, -swing) * 0.9f, 0, 0);
                    add(model, a, "shin_l", Math.max(0, swing) * 0.9f, 0, 0);
                    add(model, a, "hips", 0, 0, Mth.sin(pos * 0.3f) * 2f * speed);
                }
            }
        } else if (owner != null && stage >= 2) {
            float look = Mth.clamp(Mth.wrapDegrees(owner.getViewYRot(partial) - yaw), -45f, 45f);
            float pitch = Mth.clamp(owner.getViewXRot(partial) * 0.5f, -25f, 30f);
            add(model, a, "head", pitch, -look, 0);
        }

        // the keyframed action
        String action = switch (e.getAction()) {
            case SusanooEntity.SWING_1 -> "swing1";
            case SusanooEntity.SWING_2 -> "swing2";
            case SusanooEntity.SWING_3 -> "swing3";
            case SusanooEntity.SPECIAL -> "special";
            default -> null;
        };
        SusanooModel.Action act = action == null ? null : model.actions.get(action);
        float at = e.tickCount - e.actionStart + partial;
        if (act != null && at >= 0 && at <= act.length) sample(model, a, act, at);

        float block = Mth.lerp(partial, e.blockWeightO, e.blockWeight);
        if (block > 0.001f) {
            for (Map.Entry<String, float[]> b : model.blockPose.entrySet()) {
                float[] r = b.getValue();
                add(model, a, b.getKey(), r[0] * block, r[1] * block, r[2] * block);
            }
        }

        Matrix4f[] out = new Matrix4f[n];
        for (int i = 0; i < n; i++) {
            SusanooModel.Bone b = model.bones[i];
            Matrix4f m = b.parent >= 0 ? new Matrix4f(out[b.parent]) : new Matrix4f();
            m.translate(b.px, b.py, b.pz)
                    .rotateZYX(a[i][2] * Mth.DEG_TO_RAD, a[i][1] * Mth.DEG_TO_RAD, a[i][0] * Mth.DEG_TO_RAD)
                    .translate(-b.px, -b.py, -b.pz);
            out[i] = m;
        }
        return out;
    }

    private static void add(SusanooModel model, float[][] a, String bone, float x, float y, float z) {
        Integer i = model.boneIndex.get(bone);
        if (i == null) return;
        a[i][0] += x;
        a[i][1] += y;
        a[i][2] += z;
    }

    /** The action's pose at {@code t} ticks: eased between the two keys around it (a bone missing from a key is at rest). */
    private static void sample(SusanooModel model, float[][] a, SusanooModel.Action act, float t) {
        int[] times = act.times;
        for (int k = 0; k + 1 < times.length; k++) {
            if (t < times[k] || t > times[k + 1]) continue;
            float f = (t - times[k]) / Math.max(1e-4f, times[k + 1] - times[k]);
            f = f * f * (3 - 2 * f);
            Map<String, float[]> p0 = act.poses.get(k), p1 = act.poses.get(k + 1);
            for (String bone : model.boneIndex.keySet()) {
                float[] r0 = p0.get(bone), r1 = p1.get(bone);
                if (r0 == null && r1 == null) continue;
                float x0 = r0 == null ? 0 : r0[0], y0 = r0 == null ? 0 : r0[1], z0 = r0 == null ? 0 : r0[2];
                float x1 = r1 == null ? 0 : r1[0], y1 = r1 == null ? 0 : r1[1], z1 = r1 == null ? 0 : r1[2];
                add(model, a, bone, x0 + (x1 - x0) * f, y0 + (y1 - y0) * f, z0 + (z1 - z0) * f);
            }
            return;
        }
    }
}
