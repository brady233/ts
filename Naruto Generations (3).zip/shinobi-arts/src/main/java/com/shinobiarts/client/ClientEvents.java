package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private static boolean charging;
    private static boolean jumpWasDown;
    /** Jutsu keys pressed and not yet let go (the server is told when they come up). */
    private static final boolean[] jutsuKeyDown = new boolean[KeyBinds.JUTSU_KEYS.length];
    /** Ticks since the local player last stood on water with Chakra Control (Ninja Jump works from there too). */
    private static int ticksSinceWater = 100;
    /** Ticks until the Discord invite is shown after joining a world or server (-1 = nothing to show). */
    private static int discordDelay = -1;

    public static final String DISCORD_URL = "https://discord.gg/EGVB4Sjzu3";

    private ClientEvents() {}

    /** Ninja Jump is checked before the player moves this tick, while they're still on the ground. */
    @SubscribeEvent
    public static void onClientTickStart(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) {
            jumpWasDown = false;
            return;
        }
        boolean jumpDown = mc.options.keyJump.isDown();
        com.shinobiarts.ninja.NinjaData d = ClientNinjaData.get();
        // from the ground, or from the water while Chakra Control holds you up (sneaking lets you sink a little first)
        boolean fromWater = ticksSinceWater <= 10 && com.shinobiarts.ninja.ChakraControl.usable(player, d)
                && (player.isInWater() || com.shinobiarts.ninja.ChakraControl.nearWaterSurface(player));
        if (jumpDown && !jumpWasDown && mc.options.keyShift.isDown() && (player.onGround() || fromWater)
                && !player.getAbilities().flying && !player.isPassenger()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.NINJA_JUMP));
        }
        jumpWasDown = jumpDown;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) {
            charging = false;
            return;
        }
        if (discordDelay > 0 && --discordDelay == 0) {
            discordDelay = -1;
            mc.player.sendSystemMessage(discordInvite());
        }

        while (KeyBinds.NEXT.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.NEXT));
        while (KeyBinds.PREV.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.PREV));
        while (KeyBinds.DOJUTSU.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.DOJUTSU, 1, 0));
        while (KeyBinds.BYAKUGAN.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.DOJUTSU, 2, 0));
        while (KeyBinds.SAGE.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.SAGE_MODE));
        for (int i = 0; i < KeyBinds.JUTSU_KEYS.length; i++) {
            while (KeyBinds.JUTSU_KEYS[i].consumeClick()) {
                ModNetwork.toServer(new ActionPacket(ActionPacket.EYE_JUTSU, i + 1, mc.player.isShiftKeyDown() ? 1 : 0));
                jutsuKeyDown[i] = true;
            }
            // Kamui lasts while Jutsu 2 is held: say when a pressed key comes up (opening a screen lets go of keys too)
            if (jutsuKeyDown[i] && !KeyBinds.JUTSU_KEYS[i].isDown()) {
                jutsuKeyDown[i] = false;
                ModNetwork.toServer(new ActionPacket(ActionPacket.EYE_JUTSU_RELEASE, i + 1, 0));
            }
        }
        while (KeyBinds.SUBSTITUTION.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.SUBSTITUTION_TOGGLE));
        while (KeyBinds.CHAKRA_CONTROL.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.CHAKRA_CONTROL));
        while (KeyBinds.SUSANOO.consumeClick()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.SUSANOO, 0, mc.player.isShiftKeyDown() ? 1 : 0));
        }
        while (KeyBinds.EIGHT_GATES.consumeClick()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.EIGHT_GATES, 0, mc.player.isShiftKeyDown() ? 1 : 0));
        }
        while (KeyBinds.STATS.consumeClick()) {
            if (mc.screen == null) ClientHooks.openStats();
        }

        // Charging is held: tell the server when it starts and stops.
        boolean wantCharge = KeyBinds.CHARGE.isDown() && mc.screen == null;
        if (wantCharge != charging) {
            charging = wantCharge;
            ModNetwork.toServer(new ActionPacket(wantCharge ? ActionPacket.CHARGE_START : ActionPacket.CHARGE_STOP));
        }
    }

    /**
     * The local player, before they move this tick: Kamui's noclip (no collision while intangible, staying airborne
     * as a flyer) and Chakra Control (walking up walls, standing on water). Movement is client-side for your own player.
     */
    /**
     * Inside a Susanoo (Skeletal and up), with an empty hand: left-click swings it (the combo) instead of punching,
     * right-click uses its special.
     */
    @SubscribeEvent
    public static void onInteractionKey(net.minecraftforge.client.event.InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || event.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        // a formed Rasenshuriken: swinging at the air or a block throws it (hitting a creature slams it in instead)
        int look = ClientEyes.look(mc.player);
        if (event.isAttack() && (look & com.shinobiarts.ninja.SharinganManager.LOOK_RASENSHURIKEN) != 0
                && (look & com.shinobiarts.ninja.SharinganManager.LOOK_RASENGAN_FORMING) == 0
                && (mc.hitResult == null || mc.hitResult.getType() != net.minecraft.world.phys.HitResult.Type.ENTITY)) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.THROW_RASENSHURIKEN));
            event.setSwingHand(true);
            event.setCanceled(true);
            return;
        }
        if (ClientNinjaData.get().getSusanooStage() < 2 || !mc.player.getMainHandItem().isEmpty()) return;
        if (event.isAttack()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.SUSANOO_ATTACK));
        } else if (event.isUseItem()) {
            ModNetwork.toServer(new ActionPacket(ActionPacket.SUSANOO_SPECIAL));
        } else {
            return;
        }
        event.setSwingHand(false);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLocalPlayerTick(net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.getEntity() != mc.player || mc.player == null) return;
        LocalPlayer player = mc.player;
        com.shinobiarts.ninja.NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized()) return;
        if (d.isIntangible(player.level().getGameTime())) {
            player.noPhysics = true;
            if (player.getAbilities().mayfly && !player.getAbilities().flying) player.getAbilities().flying = true;
            return;
        }
        int susanoo = d.getSusanooStage();
        double ride = com.shinobiarts.ninja.Susanoo.rideHeight(susanoo);
        if (ride > 0) {
            // riding in the Susanoo: in the Humanoid and Armored stages' chest it walks on the ground and you stay at chest
            // height; in the Perfect Susanoo's head it flies, and its feet stay above the ground
            if (player.getAbilities().mayfly && !player.getAbilities().flying) player.getAbilities().flying = true;
            double target = com.shinobiarts.ninja.Susanoo.groundBelow(player.level(), player.getX(),
                    player.getY() - ride + 1.5, player.getZ()) + ride;
            net.minecraft.world.phys.Vec3 v = player.getDeltaMovement();
            if (com.shinobiarts.ninja.Susanoo.holdsInChest(susanoo)) {
                double dy = target - player.getY();
                if (Math.abs(dy) > 0.01) player.setPos(player.getX(), player.getY() + net.minecraft.util.Mth.clamp(dy, -0.5, 0.6), player.getZ());
                player.setDeltaMovement(v.x, 0, v.z);
            } else if (player.getY() < target) {
                player.setPos(player.getX(), Math.min(target, player.getY() + 0.6), player.getZ());
                if (v.y < 0) player.setDeltaMovement(v.x, 0, v.z);
            }
        }
        boolean wasOnCeiling = d.isOnCeiling();
        com.shinobiarts.ninja.ChakraControl.move(player, d);
        if (d.isOnCeiling() != wasOnCeiling) {                     // tell the server, so everyone sees you upside down
            ModNetwork.toServer(new ActionPacket(ActionPacket.CEILING, d.isOnCeiling() ? 1 : 0, 0));
        }
        ticksSinceWater = com.shinobiarts.ninja.ChakraControl.usable(player, d) && com.shinobiarts.ninja.ChakraControl.nearWaterSurface(player)
                ? 0 : Math.min(100, ticksSinceWater + 1);
    }

    /** Frozen (Tsukuyomi...): your own movement keys do nothing until it wears off. */
    @SubscribeEvent
    public static void onMovementInput(net.minecraftforge.client.event.MovementInputUpdateEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.getEntity() != mc.player || mc.level == null) return;
        if (!ClientNinjaData.get().isStunned(mc.level.getGameTime())) return;
        net.minecraft.client.player.Input input = event.getInput();
        input.forwardImpulse = 0;
        input.leftImpulse = 0;
        input.up = input.down = input.left = input.right = false;
        input.jumping = false;
        input.shiftKeyDown = false;
    }

    /** Replaces the vanilla hearts with a numeric health bar in the same spot above the hotbar. */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Pre event) {
        if (!event.getOverlay().id().equals(VanillaGuiOverlay.PLAYER_HEALTH.id()) || !ClientNinjaData.get().isInitialized()) return;
        event.setCanceled(true);
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.gui instanceof ForgeGui gui) || mc.player == null || mc.options.hideGui || !gui.shouldDrawSurvivalElements()) return;
        int width = event.getWindow().getGuiScaledWidth();
        int height = event.getWindow().getGuiScaledHeight();
        ShinobiHud.drawHealthBar(event.getGuiGraphics(), width / 2 - 91, height - gui.leftHeight, mc.player);
        gui.leftHeight += 10; // keep the armor bar above it, like vanilla hearts do
    }

    /** Every time you join a world or server, the Discord invite appears in chat (after the join messages). */
    @SubscribeEvent
    public static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
        discordDelay = 40;
    }

    /** The whole line is clickable and opens the Discord invite. */
    public static Component discordInvite() {
        Style link = Style.EMPTY
                .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, DISCORD_URL))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click to join the Discord")));
        return Component.literal("Join the discord here for insights on new updates and sneak peeks! ")
                .withStyle(link.withColor(ChatFormatting.GOLD))
                .append(Component.literal(DISCORD_URL).withStyle(link.withColor(ChatFormatting.AQUA).withUnderlined(true)));
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        discordDelay = -1;
        ClientEyes.clear();
        ShadowLinkRender.clear();
        WaterPrisonRender.clear();
        MindTransferClient.clear();
        com.shinobiarts.network.ConfigSyncPacket.Client.restoreLocal();
        charging = false;
        ClientNinjaData.reset();
        HeadbandLayer.clearCache();
        ShinobiHud.reset();
    }
}
