package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.block.EarthWallBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ShinobiArts.MODID);

    /** Temporary wall raised by Earth Release: Earth Wall. Crumbles on its own. */
    public static final RegistryObject<Block> EARTH_WALL = BLOCKS.register("earth_wall", () -> new EarthWallBlock(
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIRT)
                    .strength(1.5f, 6.0f)
                    .sound(SoundType.GRAVEL)
                    .noLootTable()));

    /** Amaterasu's black flames (Jutsu 1 of the Itachi, Sasuke and Eternal Mangekyou). */
    public static final RegistryObject<Block> AMATERASU_FIRE = BLOCKS.register("amaterasu_fire", () -> new com.shinobiarts.block.AmaterasuFireBlock(
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .noCollission()
                    .strength(-1.0f, 3600000.0f)
                    .lightLevel(state -> 5)
                    .sound(SoundType.WOOL)
                    .pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY)
                    .noLootTable()));

    // Clan release blocks: they break by themselves (see TemporaryBlock) and drop nothing.
    /** Wood Release: the trunks of Deep Forest Emergence and the Wood Dome. */
    public static final RegistryObject<Block> WOOD_WALL = BLOCKS.register("wood_wall", () -> new com.shinobiarts.block.TemporaryBlock(200,
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0f, 6.0f).sound(SoundType.WOOD).noLootTable()));
    /** Ice Release: Ice Prison and the Demonic Ice Mirrors. */
    public static final RegistryObject<Block> ICE_WALL = BLOCKS.register("ice_wall", () -> new com.shinobiarts.block.TemporaryBlock(60,
            BlockBehaviour.Properties.of().mapColor(MapColor.ICE).strength(0.8f, 3.0f).friction(0.98f).sound(SoundType.GLASS).noLootTable()));
    /** Magnet Release: the iron sand of the Iron Sand Coffin. */
    public static final RegistryObject<Block> IRON_SAND = BLOCKS.register("iron_sand", () -> new com.shinobiarts.block.TemporaryBlock(40,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(1.0f, 4.0f).sound(SoundType.SAND).noLootTable()));
    /** Bone (Kaguya): the spikes of the Dance of the Seedling Fern. */
    public static final RegistryObject<Block> BONE_SPIKE = BLOCKS.register("bone_spike", () -> new com.shinobiarts.block.TemporaryBlock(160,
            BlockBehaviour.Properties.of().mapColor(MapColor.SAND).strength(2.0f, 6.0f).sound(SoundType.BONE_BLOCK).noLootTable()));

    private ModBlocks() {}
}
