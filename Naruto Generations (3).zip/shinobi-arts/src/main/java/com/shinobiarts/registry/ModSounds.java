package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.ninja.EyeTechniques;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Voice lines: every jutsu (shinobiarts:jutsu.<id>) and every eye technique (shinobiarts:eye.<id>) has a sound of its
 * own, played from the caster when it goes off, on top of the jutsu's effect sounds. Each one plays
 * assets/shinobiarts/sounds/voice/<id>.ogg (mono OGG Vorbis), so adding a voice line only takes dropping the file in
 * that folder (in the mod, or a resource pack); until a file is there the sound is silent. Mind Body Transfer's plays
 * an owl's hoot (sounds/owl_hoot.ogg) until it's replaced. The list is in sounds.json.
 */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ShinobiArts.MODID);

    private static final Map<String, RegistryObject<SoundEvent>> JUTSU = new HashMap<>();
    private static final Map<String, RegistryObject<SoundEvent>> EYES = new HashMap<>();

    static {
        for (Jutsu j : Jutsus.all()) JUTSU.put(j.id(), register("jutsu." + j.id()));
        for (EyeTechniques.Technique t : EyeTechniques.Technique.values()) EYES.put(t.id(), register("eye." + t.id()));
    }

    private ModSounds() {}

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ShinobiArts.id(name)));
    }

    /** Plays a jutsu's voice line from the caster. */
    public static void jutsu(ServerPlayer p, String jutsuId) {
        play(p, JUTSU.get(jutsuId));
    }

    /** Plays an eye technique's voice line from the caster. */
    public static void eye(ServerPlayer p, String techniqueId) {
        play(p, EYES.get(techniqueId));
    }

    private static void play(ServerPlayer p, RegistryObject<SoundEvent> sound) {
        if (sound == null || !sound.isPresent()) return;
        p.level().playSound(null, p.getX(), p.getEyeY(), p.getZ(), sound.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
    }
}
