package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.RandomSource;
import net.minecraftforge.common.ForgeConfigSpec;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

import static com.shinobiarts.ninja.ChakraNature.EARTH;
import static com.shinobiarts.ninja.ChakraNature.FIRE;
import static com.shinobiarts.ninja.ChakraNature.LIGHTNING;
import static com.shinobiarts.ninja.ChakraNature.WATER;
import static com.shinobiarts.ninja.ChakraNature.WIND;
import static com.shinobiarts.ninja.ChakraNature.YIN_YANG;
import static net.minecraft.world.effect.MobEffects.DAMAGE_BOOST;
import static net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE;
import static net.minecraft.world.effect.MobEffects.DOLPHINS_GRACE;
import static net.minecraft.world.effect.MobEffects.FIRE_RESISTANCE;
import static net.minecraft.world.effect.MobEffects.JUMP;
import static net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN;
import static net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED;
import static net.minecraft.world.effect.MobEffects.NIGHT_VISION;
import static net.minecraft.world.effect.MobEffects.REGENERATION;
import static net.minecraft.world.effect.MobEffects.SLOW_FALLING;
import static net.minecraft.world.effect.MobEffects.WATER_BREATHING;

/**
 * The clans a player can be born into, rolled with /clanroll (a few rolls each, then claimed). Each has a rarity tier,
 * which sets its chance
 * (tier weights are in the "clans" config section), an optional nature affinity it's always born with, and passive
 * {@link ClanBuffs}. Clan jutsu (Shadow Possession, Palm Rotation) are tied to a clan in {@code Jutsus}.
 * Ids are saved with each player, so never rename one.
 */
public enum Clan {
    /** No clan yet: new players roll one with /clanroll. Never rolled itself. */
    NONE("none", Rarity.CLANLESS, ChatFormatting.GRAY, null, new ClanBuffs()),

    // Bonuses: potion effects kept topped up (no particles), Health Boost as permanent max health, chakra regeneration as a
    // multiplier. Traits stay: the eyes Uchiha and Hyuga are born with, fixed affinities and the clans' own jutsu.
    // ---- rare
    UCHIHA("uchiha", Rarity.RARE, ChatFormatting.DARK_RED, FIRE, new ClanBuffs().sharingan()
            .effect(MOVEMENT_SPEED, 2).effect(FIRE_RESISTANCE, 1).whileSharingan(NIGHT_VISION, 1)
            .note("clan.shinobiarts.uchiha.note")),
    SENJU("senju", Rarity.RARE, ChatFormatting.GREEN, EARTH, new ClanBuffs()
            .healthBoost(2).effect(REGENERATION, 1).effect(DAMAGE_RESISTANCE, 1).chakraRegenX(1.75f)
            .note("clan.shinobiarts.senju.note")),
    UZUMAKI("uzumaki", Rarity.RARE, ChatFormatting.RED, null, new ClanBuffs()
            .healthBoost(3).effect(REGENERATION, 2).effect(DAMAGE_RESISTANCE, 1).effect(FIRE_RESISTANCE, 1).chakraRegenX(2.0f)
            .note("clan.shinobiarts.uzumaki.note")),

    // ---- uncommon
    HYUGA("hyuga", Rarity.UNCOMMON, ChatFormatting.WHITE, null, new ClanBuffs().byakugan()
            .effect(MOVEMENT_SPEED, 1).effect(JUMP, 2).effect(DAMAGE_RESISTANCE, 1).whileByakugan(NIGHT_VISION, 1)
            .note("clan.shinobiarts.hyuga.note")),
    KURAMA("kurama", Rarity.UNCOMMON, ChatFormatting.DARK_PURPLE, null, new ClanBuffs()
            .effect(NIGHT_VISION, 1).effect(DAMAGE_RESISTANCE, 1).chakraRegenX(1.25f)),
    KAGUYA("kaguya", Rarity.UNCOMMON, ChatFormatting.WHITE, null, new ClanBuffs()
            .effect(DAMAGE_BOOST, 2).effect(DAMAGE_RESISTANCE, 2).healthBoost(2)),
    YUKI("yuki", Rarity.UNCOMMON, ChatFormatting.AQUA, WATER, new ClanBuffs()
            .effect(FIRE_RESISTANCE, 1).effect(DAMAGE_RESISTANCE, 1).effect(WATER_BREATHING, 1)),
    KAZEKAGE("kazekage", Rarity.UNCOMMON, ChatFormatting.YELLOW, EARTH, new ClanBuffs()
            .effect(DAMAGE_RESISTANCE, 2).effect(SLOW_FALLING, 1).healthBoost(2)),
    CHINOIKE("chinoike", Rarity.UNCOMMON, ChatFormatting.DARK_RED, null, new ClanBuffs()
            .effect(NIGHT_VISION, 1).effect(DAMAGE_BOOST, 1).effect(DAMAGE_RESISTANCE, 1)),
    HAGOROMO("hagoromo", Rarity.UNCOMMON, ChatFormatting.BLUE, null, new ClanBuffs()
            .healthBoost(2).effect(REGENERATION, 2).effect(DAMAGE_RESISTANCE, 2).chakraRegenX(1.5f)),

    // ---- common
    NARA("nara", Rarity.COMMON, ChatFormatting.DARK_GREEN, null, new ClanBuffs()
            .effect(NIGHT_VISION, 1).effect(MOVEMENT_SPEED, 1).effect(DAMAGE_RESISTANCE, 1)
            .note("clan.shinobiarts.nara.note")),
    AKIMICHI("akimichi", Rarity.COMMON, ChatFormatting.GOLD, null, new ClanBuffs()
            .effect(DAMAGE_BOOST, 2).effect(DAMAGE_RESISTANCE, 2).healthBoost(2).effect(MOVEMENT_SLOWDOWN, 1)),
    YAMANAKA("yamanaka", Rarity.COMMON, ChatFormatting.LIGHT_PURPLE, null, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 1).effect(NIGHT_VISION, 1).effect(DAMAGE_RESISTANCE, 1)),
    ABURAME("aburame", Rarity.COMMON, ChatFormatting.DARK_GRAY, null, new ClanBuffs()
            .effect(DAMAGE_RESISTANCE, 1).effect(NIGHT_VISION, 1).poisonImmunity().effect(MOVEMENT_SPEED, 1)),
    INUZUKA("inuzuka", Rarity.COMMON, ChatFormatting.RED, null, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 2).effect(JUMP, 2).effect(DAMAGE_BOOST, 1).effect(NIGHT_VISION, 1)),
    SARUTOBI("sarutobi", Rarity.COMMON, ChatFormatting.DARK_GREEN, FIRE, new ClanBuffs()
            .effect(DAMAGE_BOOST, 1).effect(FIRE_RESISTANCE, 1).effect(DAMAGE_RESISTANCE, 1)),
    HATAKE("hatake", Rarity.COMMON, ChatFormatting.WHITE, LIGHTNING, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 3).effect(DAMAGE_BOOST, 1).effect(DAMAGE_RESISTANCE, 1).saturation()),
    SHIMURA("shimura", Rarity.COMMON, ChatFormatting.DARK_GRAY, WIND, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 1).effect(DAMAGE_RESISTANCE, 1).effect(FIRE_RESISTANCE, 1)),
    FUMA("fuma", Rarity.COMMON, ChatFormatting.DARK_AQUA, null, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 2).effect(JUMP, 2).effect(DAMAGE_BOOST, 1)),
    HOZUKI("hozuki", Rarity.COMMON, ChatFormatting.AQUA, WATER, new ClanBuffs()
            .effect(WATER_BREATHING, 1).effect(DOLPHINS_GRACE, 2).effect(MOVEMENT_SPEED, 1)),
    HOSHIGAKI("hoshigaki", Rarity.COMMON, ChatFormatting.DARK_BLUE, WATER, new ClanBuffs()
            .effect(WATER_BREATHING, 1).effect(DOLPHINS_GRACE, 3).effect(DAMAGE_BOOST, 2).effect(DAMAGE_RESISTANCE, 1)),
    KARATACHI("karatachi", Rarity.COMMON, ChatFormatting.BLUE, WATER, new ClanBuffs()
            .effect(WATER_BREATHING, 1).effect(MOVEMENT_SPEED, 1).effect(DAMAGE_RESISTANCE, 1)),
    SHIROGANE("shirogane", Rarity.COMMON, ChatFormatting.GRAY, null, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 1).effect(NIGHT_VISION, 1).effect(DAMAGE_RESISTANCE, 1)),
    YOTSUKI("yotsuki", Rarity.COMMON, ChatFormatting.YELLOW, LIGHTNING, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 2).effect(DAMAGE_BOOST, 2).effect(JUMP, 2).effect(DAMAGE_RESISTANCE, 1)),
    KAMIZURU("kamizuru", Rarity.COMMON, ChatFormatting.GOLD, null, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 1).effect(NIGHT_VISION, 1).poisonImmunity()),
    IBURI("iburi", Rarity.COMMON, ChatFormatting.GRAY, null, new ClanBuffs()
            .effect(MOVEMENT_SPEED, 2).effect(SLOW_FALLING, 1).effect(FIRE_RESISTANCE, 1)),
    TSUCHIGUMO("tsuchigumo", Rarity.COMMON, ChatFormatting.DARK_GREEN, null, new ClanBuffs()
            .effect(DAMAGE_BOOST, 2).effect(DAMAGE_RESISTANCE, 2).healthBoost(2)),
    FUNATO("funato", Rarity.COMMON, ChatFormatting.DARK_AQUA, WATER, new ClanBuffs()
            .effect(WATER_BREATHING, 1).effect(DOLPHINS_GRACE, 2).effect(MOVEMENT_SPEED, 1)),
    TAKETORI("taketori", Rarity.COMMON, ChatFormatting.GREEN, null, new ClanBuffs()
            .effect(DAMAGE_BOOST, 2).effect(DAMAGE_RESISTANCE, 1).effect(MOVEMENT_SPEED, 1)),

    // ---- mythic
    OTSUTSUKI("otsutsuki", Rarity.MYTHIC, ChatFormatting.LIGHT_PURPLE, null, new ClanBuffs().byakugan()
            .effect(DAMAGE_BOOST, 3).effect(MOVEMENT_SPEED, 2).effect(DAMAGE_RESISTANCE, 2).effect(REGENERATION, 2).healthBoost(3)
            .effect(SLOW_FALLING, 1).chakraRegenX(1.5f));

    /** How rare a clan is. The weight of each tier is set in the config. */
    public enum Rarity {
        CLANLESS("clanless", ChatFormatting.GRAY),
        COMMON("common", ChatFormatting.WHITE),
        UNCOMMON("uncommon", ChatFormatting.GREEN),
        RARE("rare", ChatFormatting.AQUA),
        MYTHIC("mythic", ChatFormatting.GOLD);

        private final String id;
        private final ChatFormatting color;

        Rarity(String id, ChatFormatting color) {
            this.id = id;
            this.color = color;
        }

        public MutableComponent displayName() {
            return Component.translatable("rarity.shinobiarts." + id).withStyle(color);
        }

        /** Relative chance of a single clan of this tier among the weighted tiers (Mythic has a fixed chance instead). */
        public double weight() {
            ForgeConfigSpec.DoubleValue v = switch (this) {
                case CLANLESS, MYTHIC -> null; // "no clan" is never rolled; Mythic uses mythicChance
                case COMMON -> Config.COMMON_CLAN_WEIGHT;
                case UNCOMMON -> Config.UNCOMMON_CLAN_WEIGHT;
                case RARE -> Config.RARE_CLAN_WEIGHT;
            };
            return v == null ? 0.0 : Math.max(0.0, Config.d(v));
        }
    }

    private final String id;
    private final Rarity rarity;
    private final ChatFormatting color;
    @Nullable
    private final ChakraNature affinity;
    private final ClanBuffs buffs;

    Clan(String id, Rarity rarity, ChatFormatting color, @Nullable ChakraNature affinity, ClanBuffs buffs) {
        this.id = id;
        this.rarity = rarity;
        this.color = color;
        this.affinity = affinity;
        this.buffs = buffs;
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    public Rarity rarity() {
        return rarity;
    }

    /** The nature affinity members are always born with, or null for a random one. */
    @Nullable
    public ChakraNature affinity() {
        return affinity;
    }

    public ClanBuffs buffs() {
        return buffs;
    }

    public MutableComponent displayName() {
        return Component.translatable("clan.shinobiarts." + id).withStyle(color);
    }

    /** Chance of being born into this clan, 0-1. */
    public double chance() {
        double mythic = mythicChance();
        if (rarity == Rarity.MYTHIC) return mythic / Math.max(1, count(Rarity.MYTHIC));
        double total = 0;
        for (Clan c : values()) total += c.rarity.weight();
        return total <= 0 ? 0 : (1 - mythic) * rarity.weight() / total;
    }

    private static double mythicChance() {
        return Math.min(1.0, Math.max(0.0, Config.d(Config.MYTHIC_CHANCE)));
    }

    private static int count(Rarity tier) {
        int n = 0;
        for (Clan c : values()) {
            if (c.rarity == tier) n++;
        }
        return n;
    }

    /** "0.7%", or "1 in 100,000" for anything under 0.1%. */
    public static String formatChance(double chance) {
        double pct = chance * 100;
        if (pct >= 1) return String.format(java.util.Locale.ROOT, "%.0f%%", pct);
        if (pct >= 0.1) return String.format(java.util.Locale.ROOT, "%.1f%%", pct);
        if (chance <= 0) return "0%";
        return "1 in " + java.text.NumberFormat.getIntegerInstance(java.util.Locale.US).format(Math.round(1 / chance));
    }

    /** "Rare (0.7%)" */
    public MutableComponent rarityText() {
        return rarity.displayName().append(Component.literal(" (" + formatChance(chance()) + ")").withStyle(ChatFormatting.GRAY));
    }

    /** Everything a member gets: born-with nature, then each bonus. */
    public List<Component> describe() {
        List<Component> out = new ArrayList<>();
        if (affinity != null) {
            out.add(Component.translatable("clanbuff.shinobiarts.affinity", affinity.displayName()).withStyle(ChatFormatting.GRAY));
        }
        out.addAll(buffs.describe());
        return out;
    }

    /** Rolls a clan (never NONE): first the fixed Mythic chance, then the rarity weights. */
    public static Clan random(RandomSource random) {
        if (random.nextDouble() < mythicChance()) {
            List<Clan> mythic = new ArrayList<>();
            for (Clan c : values()) {
                if (c.rarity == Rarity.MYTHIC) mythic.add(c);
            }
            if (!mythic.isEmpty()) return mythic.get(random.nextInt(mythic.size()));
        }
        double total = 0;
        for (Clan c : values()) total += c.rarity.weight();
        if (total <= 0) return NARA; // every weight set to 0 in the config
        double roll = random.nextDouble() * total;
        for (Clan c : values()) {
            if (c.rarity.weight() <= 0) continue;
            roll -= c.rarity.weight();
            if (roll < 0) return c;
        }
        return NARA;
    }

    @Nullable
    public static Clan byId(String id) {
        for (Clan c : values()) {
            if (c.id.equals(id)) return c;
        }
        return null;
    }
}
