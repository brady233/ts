package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * The passive bonuses a clan gives (see {@link Clan}). Built with chained calls, e.g.
 * {@code new ClanBuffs().chakra(0.5f).regen(1f)}, and read by the stat, damage and tick code.
 * Percentages are fractions: 0.15 = +15%.
 */
public final class ClanBuffs {
    /** Effects a clan's hits can inflict on what they strike. */
    public enum OnHit {
        POISON("poison", 60, 0),
        SLOW("slow", 50, 1),
        CONFUSE("confuse", 80, 0),
        BLIND("blind", 50, 0);

        private final String id;
        private final int ticks;
        private final int amplifier;

        OnHit(String id, int ticks, int amplifier) {
            this.id = id;
            this.ticks = ticks;
            this.amplifier = amplifier;
        }

        public MobEffect effect() {
            return switch (this) {
                case POISON -> MobEffects.POISON;
                case SLOW -> MobEffects.MOVEMENT_SLOWDOWN;
                case CONFUSE -> MobEffects.CONFUSION;
                case BLIND -> MobEffects.BLINDNESS;
            };
        }

        public int ticks() {
            return ticks;
        }

        public int amplifier() {
            return amplifier;
        }
    }

    /** When a clan's potion effect is on: always, or only while its eyes are switched on. */
    public enum When { ALWAYS, SHARINGAN_ON, BYAKUGAN_ON }

    /** A potion effect the clan always has (kept topped up, no particles): Speed II, Resistance I... */
    public record Effect(MobEffect effect, int amplifier, When when) {
        public boolean activeFor(NinjaData d) {
            return switch (when) {
                case ALWAYS -> true;
                case SHARINGAN_ON -> d.isSharinganActive();
                case BYAKUGAN_ON -> d.getActiveDojutsu() == Dojutsu.BYAKUGAN;
            };
        }
    }

    final List<Effect> effects = new ArrayList<>();
    int healthBoost;        // Health Boost level, given as permanent max health (4 per level) so it never resets your hearts
    boolean poisonImmune;
    boolean saturation;     // never gets hungry

    // eyes the clan is born with
    boolean sharingan;
    boolean byakugan;
    // chakra and body
    float chakra;           // % max chakra
    float chakraRegen;      // % chakra regeneration
    float health;           // extra max health (2 = one heart)
    float regen;            // health healed every 5 seconds
    float speed;            // % movement speed
    float armor;
    float knockback;        // knockback resistance (0-1)
    // offense
    float melee;            // % melee damage (any weapon or fist)
    float fist;             // % unarmed damage (bare hand or a release scroll)
    float sword;            // % sword damage
    float thrown;           // % kunai/shuriken damage
    float jutsu;            // % damage of every jutsu
    final Map<ChakraNature, Float> nature = new EnumMap<>(ChakraNature.class); // % damage of one release's jutsu
    float genjutsu;         // added to the Genjutsu multiplier
    float cooldown;         // % shorter jutsu cooldowns
    float drainOnHit;       // chakra drained from enemy ninja per melee hit (the attacker gains it)
    final Map<OnHit, Float> onHit = new EnumMap<>(OnHit.class); // chance per melee hit
    // defense
    float dodge;            // chance to dodge an attack from a creature
    float projectileResist; // % less projectile damage
    float fallResist;       // % less fall damage
    float drainResist;      // % less chakra drained by enemies
    // other
    float xp;               // % more XP earned
    boolean nightVision;
    boolean waterBreathing;
    boolean swimming;       // Dolphin's Grace in water
    boolean sense;          // sneak: creatures nearby glow
    final List<String> notes = new ArrayList<>(); // extra lang keys (clan jutsu etc.)

    public ClanBuffs sharingan() { sharingan = true; return this; }
    public ClanBuffs byakugan() { byakugan = true; return this; }
    public ClanBuffs chakra(float v) { chakra = v; return this; }
    public ClanBuffs chakraRegen(float v) { chakraRegen = v; return this; }
    public ClanBuffs health(float v) { health = v; return this; }
    public ClanBuffs regen(float v) { regen = v; return this; }
    public ClanBuffs speed(float v) { speed = v; return this; }
    public ClanBuffs armor(float v) { armor = v; return this; }
    public ClanBuffs knockback(float v) { knockback = v; return this; }
    public ClanBuffs melee(float v) { melee = v; return this; }
    public ClanBuffs fist(float v) { fist = v; return this; }
    public ClanBuffs sword(float v) { sword = v; return this; }
    public ClanBuffs thrown(float v) { thrown = v; return this; }
    public ClanBuffs jutsu(float v) { jutsu = v; return this; }
    public ClanBuffs nature(ChakraNature n, float v) { nature.put(n, v); return this; }
    public ClanBuffs genjutsu(float v) { genjutsu = v; return this; }
    public ClanBuffs cooldown(float v) { cooldown = v; return this; }
    public ClanBuffs drainOnHit(float v) { drainOnHit = v; return this; }
    public ClanBuffs onHit(OnHit effect, float chance) { onHit.put(effect, chance); return this; }
    public ClanBuffs dodge(float v) { dodge = v; return this; }
    public ClanBuffs projectileResist(float v) { projectileResist = v; return this; }
    public ClanBuffs fallResist(float v) { fallResist = v; return this; }
    public ClanBuffs drainResist(float v) { drainResist = v; return this; }
    public ClanBuffs xp(float v) { xp = v; return this; }
    public ClanBuffs nightVision() { nightVision = true; return this; }
    public ClanBuffs waterBreathing() { waterBreathing = true; return this; }
    public ClanBuffs swimming() { swimming = true; return this; }
    public ClanBuffs sense() { sense = true; return this; }
    public ClanBuffs note(String langKey) { notes.add(langKey); return this; }

    /** A potion effect at a level (1 = I, 2 = II...). */
    public ClanBuffs effect(MobEffect effect, int level) { effects.add(new Effect(effect, level - 1, When.ALWAYS)); return this; }
    public ClanBuffs whileSharingan(MobEffect effect, int level) { effects.add(new Effect(effect, level - 1, When.SHARINGAN_ON)); return this; }
    public ClanBuffs whileByakugan(MobEffect effect, int level) { effects.add(new Effect(effect, level - 1, When.BYAKUGAN_ON)); return this; }
    /** Health Boost at a level: 4 extra max health per level (two hearts). */
    public ClanBuffs healthBoost(int level) { healthBoost = level; health = 4f * level; return this; }
    /** Chakra regeneration as a multiplier: 1.75 = 1.75x. */
    public ClanBuffs chakraRegenX(float times) { chakraRegen = times - 1f; return this; }
    public ClanBuffs poisonImmunity() { poisonImmune = true; return this; }
    public ClanBuffs saturation() { saturation = true; return this; }

    public List<Effect> effects() { return effects; }
    public boolean poisonImmune() { return poisonImmune; }
    public boolean neverHungry() { return saturation; }

    public boolean sharinganAtBirth() { return sharingan; }
    public boolean hasByakugan() { return byakugan; }
    public float chakra() { return chakra; }
    public float chakraRegen() { return chakraRegen; }
    public float health() { return health; }
    public float regen() { return regen; }
    public float speed() { return speed; }
    public float armor() { return armor; }
    public float knockback() { return knockback; }
    public float melee() { return melee; }
    public float fist() { return fist; }
    public float sword() { return sword; }
    public float thrown() { return thrown; }
    public float genjutsu() { return genjutsu; }
    public float cooldown() { return cooldown; }
    public float drainOnHit() { return drainOnHit; }
    public Map<OnHit, Float> onHitEffects() { return onHit; }
    public float dodge() { return dodge; }
    public float projectileResist() { return projectileResist; }
    public float fallResist() { return fallResist; }
    public float drainResist() { return drainResist; }
    public float xp() { return xp; }
    public boolean hasNightVision() { return nightVision; }
    public boolean breathesUnderwater() { return waterBreathing; }
    public boolean swimsFast() { return swimming; }
    public boolean senses() { return sense; }

    /** Damage multiplier for a jutsu of the given release: every-jutsu bonus plus that release's bonus. */
    public float jutsuMultiplier(ChakraNature release) {
        return 1f + jutsu + (release == null ? 0f : nature.getOrDefault(release, 0f));
    }

    /** One line per bonus, for the stats menu tooltip, /clan and the welcome message. */
    public List<Component> describe() {
        List<Component> out = new ArrayList<>();
        if (sharingan) out.add(line("sharingan"));
        if (byakugan) out.add(line("byakugan"));
        for (Effect e : effects) {
            MutableComponent name = Component.translatable(e.effect().getDescriptionId())
                    .append(" ").append(Component.translatable("enchantment.level." + (e.amplifier() + 1)));
            if (e.when() == When.SHARINGAN_ON) name = line("while_sharingan", name);
            else if (e.when() == When.BYAKUGAN_ON) name = line("while_byakugan", name);
            out.add(name.withStyle(ChatFormatting.GRAY));
        }
        if (healthBoost > 0) {
            out.add(Component.translatable(MobEffects.HEALTH_BOOST.getDescriptionId()).append(" ")
                    .append(Component.translatable("enchantment.level." + healthBoost)).withStyle(ChatFormatting.GRAY));
        }
        if (poisonImmune) out.add(line("poison_immunity"));
        if (saturation) out.add(line("saturation"));
        if (chakraRegen > 0 && effects.size() + healthBoost > 0) out.add(line("chakra_regen_x", num(1f + chakraRegen)));
        if (chakra > 0) out.add(line("chakra", pct(chakra)));
        if (chakraRegen > 0 && effects.size() + healthBoost == 0) out.add(line("chakra_regen", pct(chakraRegen)));
        if (health > 0 && healthBoost == 0) out.add(line("health", num(health)));
        if (regen > 0) out.add(line("regen", num(regen)));
        if (speed > 0) out.add(line("speed", pct(speed)));
        if (armor > 0) out.add(line("armor", num(armor)));
        if (knockback > 0) out.add(line("knockback", pct(knockback)));
        if (melee > 0) out.add(line("melee", pct(melee)));
        if (fist > 0) out.add(line("fist", pct(fist)));
        if (sword > 0) out.add(line("sword", pct(sword)));
        if (thrown > 0) out.add(line("thrown", pct(thrown)));
        if (jutsu > 0) out.add(line("jutsu", pct(jutsu)));
        nature.forEach((n, v) -> out.add(line("nature", pct(v), n.displayName())));
        if (genjutsu > 0) out.add(line("genjutsu", pct(genjutsu)));
        if (cooldown > 0) out.add(line("cooldown", pct(cooldown)));
        if (drainOnHit > 0) out.add(line("drain", num(drainOnHit)));
        onHit.forEach((e, chance) -> out.add(line("on_hit." + e.id, pct(chance))));
        if (dodge > 0) out.add(line("dodge", pct(dodge)));
        if (projectileResist > 0) out.add(line("projectile", pct(projectileResist)));
        if (fallResist > 0) out.add(line("fall", pct(fallResist)));
        if (drainResist > 0) out.add(line("drain_resist", pct(drainResist)));
        if (xp > 0) out.add(line("xp", pct(xp)));
        if (nightVision) out.add(line("night_vision"));
        if (waterBreathing) out.add(line("water_breathing"));
        if (swimming) out.add(line("swimming"));
        if (sense) out.add(line("sense"));
        for (String key : notes) out.add(Component.translatable(key).withStyle(ChatFormatting.GRAY));
        return out;
    }

    private static MutableComponent line(String key, Object... args) {
        return Component.translatable("clanbuff.shinobiarts." + key, args).withStyle(ChatFormatting.GRAY);
    }

    private static String pct(float v) {
        return String.valueOf(Math.round(v * 100));
    }

    private static String num(float v) {
        return v == Math.floor(v) ? String.valueOf((int) v) : String.format(java.util.Locale.ROOT, "%.1f", v);
    }
}
