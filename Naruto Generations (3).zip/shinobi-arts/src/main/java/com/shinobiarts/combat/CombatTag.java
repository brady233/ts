package com.shinobiarts.combat;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.pvp.PvpRewards;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Combat tag: hitting or being hit by another player (directly, with a jutsu or through your clones) puts BOTH
 * players in combat for 60 seconds. While in combat every command is blocked, and logging out kills you
 * (your opponent gets the kill). The on-screen "In Combat (60) - Username" is drawn by client/CombatHud.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CombatTag {
    private CombatTag() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onHurt(LivingHurtEvent event) {
        if (event.isCanceled() || event.getAmount() <= 0 || !(event.getEntity() instanceof ServerPlayer victim)) return;
        ServerPlayer attacker = PvpRewards.responsiblePlayer(event.getSource());
        if (attacker == null || attacker == victim) return;
        int seconds = Config.i(Config.COMBAT_TAG_SECONDS);
        if (seconds <= 0) return;
        tag(attacker, victim, seconds);
        tag(victim, attacker, seconds);
    }

    private static void tag(ServerPlayer player, ServerPlayer opponent, int seconds) {
        NinjaData d = NinjaData.get(player);
        if (d == null || player.isCreative() || player.isSpectator()) return;
        long now = player.level().getGameTime();
        boolean wasTagged = d.isInCombat(now);
        d.setCombat(now + seconds * 20L, opponent.getGameProfile().getName(), opponent.getUUID());
        if (!wasTagged) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.combat_start", opponent.getGameProfile().getName(), seconds)
                    .withStyle(ChatFormatting.RED));
        }
        ModNetwork.sync(player);
    }

    /** True if the player is combat-tagged right now. */
    public static boolean inCombat(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        return d != null && d.isInCombat(player.level().getGameTime());
    }

    /** Every command (from any mod) is refused for a tagged player, so nobody can teleport or warp out of a fight. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onCommand(CommandEvent event) {
        if (!Config.b(Config.COMBAT_BLOCK_COMMANDS)) return;
        CommandSourceStack source = event.getParseResults().getContext().getSource();
        if (!(source.getEntity() instanceof ServerPlayer player)) return;
        NinjaData d = NinjaData.get(player);
        long now = player.level().getGameTime();
        if (d == null || !d.isInCombat(now)) return;
        event.setCanceled(true);
        long seconds = (d.getCombatUntil() - now + 19) / 20;
        player.sendSystemMessage(Component.translatable("message.shinobiarts.combat_no_commands", seconds).withStyle(ChatFormatting.RED));
    }

    /** Combat logging: the player dies on the spot (items drop) and the opponent is credited with the kill. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!Config.b(Config.COMBAT_LOG_KILL) || !(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData d = NinjaData.get(player);
        if (d == null || !d.isInCombat(player.level().getGameTime()) || !player.isAlive()) return;
        ServerPlayer opponent = d.getCombatWithId() == null ? null : player.server.getPlayerList().getPlayer(d.getCombatWithId());
        DamageSource source = opponent != null && opponent != player
                ? player.damageSources().playerAttack(opponent) : player.damageSources().genericKill();
        player.server.getPlayerList().broadcastSystemMessage(Component.translatable("message.shinobiarts.combat_logged",
                player.getGameProfile().getName()).withStyle(ChatFormatting.RED), false);
        d.clearCombat();
        player.setHealth(0f);
        player.die(source);
    }
}
