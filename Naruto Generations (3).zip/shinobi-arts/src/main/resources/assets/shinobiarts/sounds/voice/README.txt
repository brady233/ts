Voice lines for jutsu go in this folder, one mono OGG Vorbis file per jutsu, named after the jutsu's id:

  <jutsu id>.ogg        e.g. majestic_destroyer_flame.ogg, fireball.ogg, rasengan.ogg, water_shark.ogg
  eye_<technique>.ogg   e.g. eye_amaterasu.ogg, eye_tsukuyomi.ogg, eye_kamui.ogg

The full list of names is in the README ("Jutsu voice lines"). A file plays from the caster every time that jutsu goes
off; jutsu without a file stay silent (the game logs one "missing sound" line for each at startup, which is harmless).
Mind Body Transfer plays sounds/owl_hoot.ogg; to replace it, change its entry in assets/shinobiarts/sounds.json.
Files must be mono to be heard from where the caster stands (stereo files play at full volume everywhere).
